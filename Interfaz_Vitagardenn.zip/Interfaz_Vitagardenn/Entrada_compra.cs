﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_entrada_compra : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_entrada_compra obj_Entrada_compra = new Clase_entrada_compra();
        public Frm_entrada_compra()
        {
            InitializeComponent();
        }

        private void txt_codigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {
            obj_Entrada_compra.id_entrada_compraM = long.Parse(txt_codigo.Text);
            obj_Entrada_compra.insertar_entrada_compra();
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            obj_Entrada_compra.id_entrada_compraM = long.Parse(txt_codigo.Text);
            obj_Entrada_compra.fechaM = txt_fecha.Text;
            obj_Entrada_compra.estadoM = txt_estado.Text;
            obj_Entrada_compra.id_empleado_fk_entrada_compraM = long.Parse(txt_codigo_empleado.Text);
            obj_Entrada_compra.insertar_entrada_compra();
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_email_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Entrada_compra.Consultageneral_entrada_compra(ref dgv_entrada_compra);
        }

        private void Frm_entrada_compra_Load(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click_1(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj_Entrada_compra.id_entrada_compraM = long.Parse(txt_codigo.Text);
            obj_Entrada_compra.fechaM = txt_fecha.Text;
            obj_Entrada_compra.estadoM = txt_estado.Text;
            obj_Entrada_compra.id_compra_fk_entrada_compraM = long.Parse(txt_codigo_compra.Text);
            obj_Entrada_compra.id_empleado_fk_entrada_compraM = long.Parse(txt_codigo_empleado.Text);
            obj_Entrada_compra.insertar_entrada_compra();
        }

        private void lb_volver_Click_1(object sender, EventArgs e)
        {

        }

        private void ptb_volver_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void pnl_izquierda_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Pnl_arriba_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Entrada_compra.Consultageneral_entrada_compra(ref dgv_entrada_compra);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la entrada de la compra que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Entrada_compra.id_entrada_compraM = long.Parse(txt_codigo.Text);
                obj_Entrada_compra.fechaM = txt_fecha.Text;
                obj_Entrada_compra.estadoM = txt_estado.Text;
                obj_Entrada_compra.id_compra_fk_entrada_compraM = long.Parse(txt_codigo_compra.Text);
                obj_Entrada_compra.id_empleado_fk_entrada_compraM = long.Parse(txt_codigo_empleado.Text);
                obj_Entrada_compra.actualizar_entrada_compra();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_fecha.Text = "";
            txt_estado.Text = "";
            txt_codigo_compra.Text = "";
            txt_codigo_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la entrada de la compra que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Entrada_compra.id_entrada_compraM = long.Parse(txt_codigo.Text);
                obj_Entrada_compra.eliminar_entrada_compra();
            }
        }

        private void txt_codigo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_codigo_compra_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}

