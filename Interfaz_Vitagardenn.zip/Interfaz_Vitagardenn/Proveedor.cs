﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Proveedor : Form
    {
        LOGICA.Clase_proveedor obj_Proveedor = new Clase_proveedor();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Proveedor()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
  
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Proveedor.id_proveedorM = long.Parse(txt_codigo.Text);
            obj_Proveedor.nombre_proveedorM = txt_nombre.Text;
            obj_Proveedor.valor_proveedorM = float.Parse(txt_valor.Text);
            obj_Proveedor.ciudad_proveedorM = txt_ciudad.Text;
            obj_Proveedor.direccion_proveedorM = txt_direccion.Text;
            obj_Proveedor.estado_proveedorM = txt_estado.Text;
            obj_Proveedor.id_empleado_fk_proveedorM = long.Parse(txt_cod_empleado.Text);
            obj_Proveedor.insertar_proveedor();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Proveedor.Consultageneral_proveedor(ref dgv_proveedor);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del proveedor que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Proveedor.id_proveedorM = long.Parse(txt_codigo.Text);
                obj_Proveedor.nombre_proveedorM = txt_nombre.Text;
                obj_Proveedor.valor_proveedorM = float.Parse(txt_valor.Text);
                obj_Proveedor.ciudad_proveedorM = txt_ciudad.Text;
                obj_Proveedor.direccion_proveedorM = txt_direccion.Text;
                obj_Proveedor.estado_proveedorM = txt_estado.Text;
                obj_Proveedor.id_empleado_fk_proveedorM = long.Parse(txt_cod_empleado.Text);
                obj_Proveedor.actualizar_proveedor();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_valor.Text = "";
            txt_ciudad.Text = "";
            txt_direccion.Text = "";
            txt_estado.Text = "";
            txt_cod_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del proveedor que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Proveedor.id_proveedorM = long.Parse(txt_codigo.Text);
                obj_Proveedor.eliminar_proveedor();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_ciudad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_cod_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
