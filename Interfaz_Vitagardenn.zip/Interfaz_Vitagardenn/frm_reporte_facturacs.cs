﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class frm_reporte_facturacs : Form
    {
        public frm_reporte_facturacs()
        {
            InitializeComponent();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_Factura factura = new frm_Menu_Factura();
            factura.Show();
            this.Hide();
        }
    }
}
