﻿using LOGICA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Salida_producto : Form
    {

        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_salida_producto obj_Salida_producto = new Clase_salida_producto();
        public Frm_Salida_producto()
        {
            InitializeComponent();
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Salida_producto.cantidadM = int.Parse(txt_cantidad.Text);
            obj_Salida_producto.valorM = float.Parse(txt_valor.Text);
            obj_Salida_producto.id_producto_fk_salida_productoM = long.Parse(txt_codigo_producto.Text);
            obj_Salida_producto.id_salida_inventario_fk_salida_productoM = long.Parse(txt_codigo_salida_inventario.Text);
            obj_Salida_producto.insertar_salida_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Salida_producto.Consultageneral_salida_producto(ref dgv_salida_producto);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_cantidad.Text == "")
            {
                MessageBox.Show("Digite la cantidad de la salida del producto que desea actualizar");
            }
            else if (txt_cantidad.Text != "")
            {
                obj_Salida_producto.cantidadM = int.Parse(txt_cantidad.Text);
                obj_Salida_producto.valorM = float.Parse(txt_valor.Text);
                obj_Salida_producto.id_producto_fk_salida_productoM = long.Parse(txt_codigo_producto.Text);
                obj_Salida_producto.id_salida_inventario_fk_salida_productoM = long.Parse(txt_codigo_salida_inventario.Text);
                obj_Salida_producto.actualizar_salida_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_cantidad.Text = "";
            txt_valor.Text = "";
            txt_codigo_producto.Text = "";
            txt_codigo_salida_inventario.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_cantidad.Text == "")
            {
                MessageBox.Show("Digite la cantiadd de la salida del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Salida_producto.cantidadM = int.Parse(txt_cantidad.Text);
                obj_Salida_producto.eliminar_salida_producto();
            }
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_salida_inventario_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
