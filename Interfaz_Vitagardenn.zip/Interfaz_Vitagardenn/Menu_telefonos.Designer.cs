﻿
namespace Vitagardenn_interfaz
{
    partial class frm_Menu_telefonos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Menu_telefonos));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.Btn_telefono_empleado = new System.Windows.Forms.Button();
            this.Btn_telefono_cliente = new System.Windows.Forms.Button();
            this.Btn_telefono_proveedor = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(67, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 57);
            this.label2.TabIndex = 7;
            this.label2.Text = "|";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(120, 85);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 33);
            this.label1.TabIndex = 6;
            this.label1.Text = "TELÉFONOS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(15, 21);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            this.Ptb_titulo.Click += new System.EventHandler(this.Ptb_titulo_Click);
            // 
            // Btn_telefono_empleado
            // 
            this.Btn_telefono_empleado.BackColor = System.Drawing.Color.White;
            this.Btn_telefono_empleado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_telefono_empleado.Location = new System.Drawing.Point(51, 166);
            this.Btn_telefono_empleado.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_telefono_empleado.Name = "Btn_telefono_empleado";
            this.Btn_telefono_empleado.Size = new System.Drawing.Size(295, 103);
            this.Btn_telefono_empleado.TabIndex = 8;
            this.Btn_telefono_empleado.Text = "TELÉFONO EMPLEADO";
            this.Btn_telefono_empleado.UseVisualStyleBackColor = false;
            this.Btn_telefono_empleado.Click += new System.EventHandler(this.Btn_telefono_empleado_Click);
            // 
            // Btn_telefono_cliente
            // 
            this.Btn_telefono_cliente.BackColor = System.Drawing.Color.White;
            this.Btn_telefono_cliente.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_telefono_cliente.Location = new System.Drawing.Point(384, 166);
            this.Btn_telefono_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_telefono_cliente.Name = "Btn_telefono_cliente";
            this.Btn_telefono_cliente.Size = new System.Drawing.Size(295, 103);
            this.Btn_telefono_cliente.TabIndex = 9;
            this.Btn_telefono_cliente.Text = "TELÉFONO CLIENTE";
            this.Btn_telefono_cliente.UseVisualStyleBackColor = false;
            this.Btn_telefono_cliente.Click += new System.EventHandler(this.Btn_telefono_cliente_Click);
            // 
            // Btn_telefono_proveedor
            // 
            this.Btn_telefono_proveedor.BackColor = System.Drawing.Color.White;
            this.Btn_telefono_proveedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_telefono_proveedor.Location = new System.Drawing.Point(719, 166);
            this.Btn_telefono_proveedor.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_telefono_proveedor.Name = "Btn_telefono_proveedor";
            this.Btn_telefono_proveedor.Size = new System.Drawing.Size(295, 103);
            this.Btn_telefono_proveedor.TabIndex = 10;
            this.Btn_telefono_proveedor.Text = "TELÉFONO PROVEEDOR";
            this.Btn_telefono_proveedor.UseVisualStyleBackColor = false;
            this.Btn_telefono_proveedor.Click += new System.EventHandler(this.Btn_telefono_proveedor_Click);
            // 
            // frm_Menu_telefonos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.image__2_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.Btn_telefono_proveedor);
            this.Controls.Add(this.Btn_telefono_cliente);
            this.Controls.Add(this.Btn_telefono_empleado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ptb_titulo);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_Menu_telefonos";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  INFORMACIÓN TELÉFONOS";
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_telefono_empleado;
        private System.Windows.Forms.Button Btn_telefono_cliente;
        private System.Windows.Forms.Button Btn_telefono_proveedor;
    }
}