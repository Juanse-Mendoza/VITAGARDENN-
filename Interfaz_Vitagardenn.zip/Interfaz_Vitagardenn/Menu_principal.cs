﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Menu_mod_principal : Form
    {
        public Frm_Menu_mod_principal()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            frm_Entrada_planta entrada_Planta = new frm_Entrada_planta();
            entrada_Planta.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Frm_Salida_producto salida_Producto = new Frm_Salida_producto();
            salida_Producto.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Frm_entrada_compra entrada_Compra = new Frm_entrada_compra();
            entrada_Compra.Show();
            this.Hide();
        }

        private void Menu_principal_Load(object sender, EventArgs e)
        {

        }

        private void Btn_cliente_Click(object sender, EventArgs e)
        {
            Frm_cliente cliente = new Frm_cliente();
            cliente.Show();
            this.Hide();
        }

        private void Btn_compra_Click(object sender, EventArgs e)
        {
            Frm_Compra compra = new Frm_Compra();
            compra.Show();
            this.Hide();
        }

        private void Btn_venta_Click(object sender, EventArgs e)
        {
            Frm_Venta venta = new Frm_Venta();
            venta.Show();
            this.Hide();
        }

        private void Btn_empleado_Click(object sender, EventArgs e)
        {
            Frm_Empleado empleado = new Frm_Empleado();
            empleado.Show();
            this.Hide();
        }

        private void Btn_usuario_Click(object sender, EventArgs e)
        {
            Frm_Usuario usuario = new Frm_Usuario();
            usuario.Show();
            this.Hide();
        }

        private void Btn_proveedor_Click(object sender, EventArgs e)
        {
            Frm_Proveedor proveedor = new Frm_Proveedor();
            proveedor.Show();
            this.Hide();
        }

        private void Ptb_titulo_Click(object sender, EventArgs e)
        {
            frm_Menu_priincipal priin = new frm_Menu_priincipal();
            priin.Show();
            this.Hide();
        }
    }
}
