﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Especie : Form
    {
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_especie obj_Especie = new Clase_especie();
        public Frm_Especie()
        {
            InitializeComponent();
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Especie.id_especieM = long.Parse(txt_codigo.Text);
            obj_Especie.nombre_especieM = txt_nombre.Text;
            obj_Especie.estado_especieM = txt_estado.Text;
            obj_Especie.insertar_especie();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Especie.Consultageneral_especie(ref dgv_especie);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos productos = new Frm_Menu_productos();
            productos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la especie que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Especie.id_especieM = long.Parse(txt_codigo.Text);
                obj_Especie.nombre_especieM = txt_nombre.Text;
                obj_Especie.estado_especieM = txt_estado.Text;
                obj_Especie.actualizar_especie();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_estado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la especie que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Especie.id_especieM = long.Parse(txt_codigo.Text);
                obj_Especie.eliminar_especie();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }
    }
}
