﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Menu_productos : Form
    {
        public Frm_Menu_productos()
        {
            InitializeComponent();
        }

        private void Menu_productos_Load(object sender, EventArgs e)
        {

        }

        private void Btn_planta_Click(object sender, EventArgs e)
        {
            Frm_Planta planta = new Frm_Planta();
            planta.Show();
            this.Hide();
        }

        private void Btn_especie_Click(object sender, EventArgs e)
        {
            Frm_Especie especie = new Frm_Especie();
            especie.Show();
            this.Hide();
        }

        private void Btn_producto_Click(object sender, EventArgs e)
        {
            Frm_Producto producto = new Frm_Producto();
            producto.Show();
            this.Hide();
        }

        private void Btn_Tipo_producto_Click(object sender, EventArgs e)
        {
            Frm_Tipo_producto tipo_Producto = new Frm_Tipo_producto();
            tipo_Producto.Show();
            this.Hide();
        }

        private void Btn_marca_Click(object sender, EventArgs e)
        {
            Frm_Marca marca = new Frm_Marca();
            marca.Show();
            this.Hide();
        }

        private void Ptb_titulo_Click(object sender, EventArgs e)
        {
            frm_Menu_priincipal priin = new frm_Menu_priincipal();
            priin.Show();
            this.Hide();
        }
    }
}
