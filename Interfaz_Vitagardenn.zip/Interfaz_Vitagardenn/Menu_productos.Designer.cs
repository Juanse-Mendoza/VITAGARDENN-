﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_Menu_productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Menu_productos));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.Btn_planta = new System.Windows.Forms.Button();
            this.Btn_especie = new System.Windows.Forms.Button();
            this.Btn_producto = new System.Windows.Forms.Button();
            this.Btn_Tipo_producto = new System.Windows.Forms.Button();
            this.Btn_marca = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(65, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 57);
            this.label2.TabIndex = 7;
            this.label2.Text = "|";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(119, 78);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 33);
            this.label1.TabIndex = 6;
            this.label1.Text = "INFORMACIÓN PRODUCTOS";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(13, 14);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            this.Ptb_titulo.Click += new System.EventHandler(this.Ptb_titulo_Click);
            // 
            // Btn_planta
            // 
            this.Btn_planta.BackColor = System.Drawing.Color.White;
            this.Btn_planta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_planta.Location = new System.Drawing.Point(35, 176);
            this.Btn_planta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_planta.Name = "Btn_planta";
            this.Btn_planta.Size = new System.Drawing.Size(295, 103);
            this.Btn_planta.TabIndex = 8;
            this.Btn_planta.Text = "PLANTA";
            this.Btn_planta.UseVisualStyleBackColor = false;
            this.Btn_planta.Click += new System.EventHandler(this.Btn_planta_Click);
            // 
            // Btn_especie
            // 
            this.Btn_especie.BackColor = System.Drawing.Color.White;
            this.Btn_especie.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_especie.Location = new System.Drawing.Point(369, 176);
            this.Btn_especie.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_especie.Name = "Btn_especie";
            this.Btn_especie.Size = new System.Drawing.Size(295, 103);
            this.Btn_especie.TabIndex = 9;
            this.Btn_especie.Text = "ESPECIE";
            this.Btn_especie.UseVisualStyleBackColor = false;
            this.Btn_especie.Click += new System.EventHandler(this.Btn_especie_Click);
            // 
            // Btn_producto
            // 
            this.Btn_producto.BackColor = System.Drawing.Color.White;
            this.Btn_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_producto.Location = new System.Drawing.Point(693, 176);
            this.Btn_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_producto.Name = "Btn_producto";
            this.Btn_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_producto.TabIndex = 10;
            this.Btn_producto.Text = "PRODUCTO";
            this.Btn_producto.UseVisualStyleBackColor = false;
            this.Btn_producto.Click += new System.EventHandler(this.Btn_producto_Click);
            // 
            // Btn_Tipo_producto
            // 
            this.Btn_Tipo_producto.BackColor = System.Drawing.Color.White;
            this.Btn_Tipo_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Tipo_producto.Location = new System.Drawing.Point(187, 325);
            this.Btn_Tipo_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_Tipo_producto.Name = "Btn_Tipo_producto";
            this.Btn_Tipo_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_Tipo_producto.TabIndex = 11;
            this.Btn_Tipo_producto.Text = "TIPO PRODUCTO";
            this.Btn_Tipo_producto.UseVisualStyleBackColor = false;
            this.Btn_Tipo_producto.Click += new System.EventHandler(this.Btn_Tipo_producto_Click);
            // 
            // Btn_marca
            // 
            this.Btn_marca.BackColor = System.Drawing.Color.White;
            this.Btn_marca.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_marca.Location = new System.Drawing.Point(537, 325);
            this.Btn_marca.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_marca.Name = "Btn_marca";
            this.Btn_marca.Size = new System.Drawing.Size(295, 103);
            this.Btn_marca.TabIndex = 12;
            this.Btn_marca.Text = "MARCA";
            this.Btn_marca.UseVisualStyleBackColor = false;
            this.Btn_marca.Click += new System.EventHandler(this.Btn_marca_Click);
            // 
            // Frm_Menu_productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.image1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1028, 618);
            this.Controls.Add(this.Btn_marca);
            this.Controls.Add(this.Btn_Tipo_producto);
            this.Controls.Add(this.Btn_producto);
            this.Controls.Add(this.Btn_especie);
            this.Controls.Add(this.Btn_planta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ptb_titulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frm_Menu_productos";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Menú Información Productos";
            this.Load += new System.EventHandler(this.Menu_productos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_planta;
        private System.Windows.Forms.Button Btn_especie;
        private System.Windows.Forms.Button Btn_producto;
        private System.Windows.Forms.Button Btn_Tipo_producto;
        private System.Windows.Forms.Button Btn_marca;
    }
}