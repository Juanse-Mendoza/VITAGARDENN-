﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Marca : Form
    {
        LOGICA.Clase_marca obj_Marca = new Clase_marca();
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Marca()
        {
            InitializeComponent();
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Marca.Consultageneral_marca(ref dgv_marca);
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Marca.id_marcaM = long.Parse(txt_codigo.Text);
            obj_Marca.nombre_marcaM = txt_nombre.Text;
            obj_Marca.id_producto_fk_marcaM = long.Parse(txt_producto.Text);
            obj_Marca.insertar_marca();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Marca.Consultageneral_marca(ref dgv_marca);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos productos = new Frm_Menu_productos();
            productos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la marca que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Marca.id_marcaM = long.Parse(txt_codigo.Text);
                obj_Marca.nombre_marcaM = txt_nombre.Text;
                obj_Marca.id_producto_fk_marcaM = long.Parse(txt_producto.Text);
                obj_Marca.actualizar_marca();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_producto.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la marca que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Marca.id_marcaM = long.Parse(txt_codigo.Text);
                obj_Marca.eliminar_marca();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
