﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Producto : Form
    {
        LOGICA.Clase_producto obj_Producto = new Clase_producto();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Producto()
        {
            InitializeComponent();
        }

        private void Frm_Producto_Load(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Producto.id_productoM = long.Parse(txt_codigo.Text);
            obj_Producto.nombre_productoM = txt_nombre.Text;
            obj_Producto.valor_productoM = float.Parse(txt_valor.Text);
            obj_Producto.cantidad_productoM = int.Parse(txt_cantidad.Text);
            obj_Producto.estado_productoM = txt_estado.Text;
            obj_Producto.id_empleado_fk_productoM = long.Parse(txt_empleado.Text);
            obj_Producto.id_proveedor_fk_productoM = long.Parse(txt_codigo_proveedor.Text);
            obj_Producto.insertar_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Producto.Consultageneral_producto(ref dgv_producto);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos productos = new Frm_Menu_productos();
            productos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del producto que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Producto.id_productoM = long.Parse(txt_codigo.Text);
                obj_Producto.nombre_productoM = txt_nombre.Text;
                obj_Producto.valor_productoM = float.Parse(txt_valor.Text);
                obj_Producto.cantidad_productoM = int.Parse(txt_cantidad.Text);
                obj_Producto.estado_productoM = txt_estado.Text;
                obj_Producto.id_empleado_fk_productoM = long.Parse(txt_empleado.Text);
                obj_Producto.id_proveedor_fk_productoM = long.Parse(txt_codigo_proveedor.Text);
                obj_Producto.actualizar_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_valor.Text = "";
            txt_cantidad.Text = "";
            txt_estado.Text = "";
            txt_empleado.Text = "";
            txt_codigo_proveedor.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Producto.id_productoM = long.Parse(txt_codigo.Text);
                obj_Producto.eliminar_producto();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_proveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }
    }
}
