﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class frm_Det_salida_inventario_producto : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_det_salida_inventario obj_salida_producto = new Clase_det_salida_inventario();
        public frm_Det_salida_inventario_producto()
        {
            InitializeComponent();
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles detalles = new frm_Menu_detalles();
            detalles.Show();
            this.Hide();
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_salida_producto.id_salida_inventarioM = long.Parse(txt_codigo.Text);
            obj_salida_producto.fechaM = txt_fecha.Text;
            obj_salida_producto.estadoM = txt_estado.Text;
            obj_salida_producto.id_venta_fk_salida_inventarioM = long.Parse(txt_codigo_venta.Text);
            obj_salida_producto.id_empleado_fk_salida_inventarioM = long.Parse(txt_cod_empleado.Text);
            obj_salida_producto.insertar_salida_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_salida_producto.Consultageneral_salida_producto(ref dgv_salida_inventario_producto);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite la cantidad de la salida del producto que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_salida_producto.id_salida_inventarioM = long.Parse(txt_codigo.Text);
                obj_salida_producto.fechaM = txt_fecha.Text;
                obj_salida_producto.estadoM = txt_estado.Text;
                obj_salida_producto.id_venta_fk_salida_inventarioM = long.Parse(txt_codigo_venta.Text);
                obj_salida_producto.id_empleado_fk_salida_inventarioM = long.Parse(txt_cod_empleado.Text);
                obj_salida_producto.actualizar_salida_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_fecha.Text = "";
            txt_estado.Text = "";
            txt_cod_empleado.Text = "";
            txt_codigo_venta.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite la cantidad de la salida del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_salida_producto.id_salida_inventarioM = long.Parse(txt_codigo.Text);
                obj_salida_producto.eliminar_salida_producto();
            }
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void txt_codigo_salida_inventario_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cod_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
