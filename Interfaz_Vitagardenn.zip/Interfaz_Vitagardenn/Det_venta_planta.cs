﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Det_venta_planta : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_detalle_venta_planta obj_Venta_planta = new Clase_detalle_venta_planta();
        public Frm_Det_venta_planta()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {

        }

        private void txt_observaciones_TextChanged(object sender, EventArgs e)
        {

        }



        private void ptb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_observaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txt_codigo_planta_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_venta_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Venta_planta.Consultageneral_venta_planta(ref dgv_Det_venta_planta);
        }

        private void lb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Venta_planta.observaciones_venta_plantaM = (txt_observaciones.Text);
            obj_Venta_planta.cantidadM = int.Parse(txt_cantidad.Text);
            obj_Venta_planta.subtotalM = float.Parse(txt_subtotal.Text);
            obj_Venta_planta.id_venta_fk_venta_plantaM = long.Parse(txt_codigo_venta.Text);
            obj_Venta_planta.id_planta_fk_venta_plantaM = long.Parse(txt_codigo_planta.Text);
            obj_Venta_planta.insertar_venta_planta();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Venta_planta.Consultageneral_venta_planta(ref dgv_Det_venta_planta);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles detalles = new frm_Menu_detalles();
            detalles.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_venta.Text == "")
            {
                MessageBox.Show("Digite el codigo de la venta para actualizar");
            }
            else if (txt_codigo_venta.Text != "")
            {
                obj_Venta_planta.observaciones_venta_plantaM = txt_observaciones.Text;
                obj_Venta_planta.cantidadM = int.Parse(txt_cantidad.Text);
                obj_Venta_planta.subtotalM = float.Parse(txt_subtotal.Text);
                obj_Venta_planta.id_venta_fk_venta_plantaM = long.Parse(txt_codigo_venta.Text);
                obj_Venta_planta.id_planta_fk_venta_plantaM = long.Parse(txt_codigo_planta.Text);
                obj_Venta_planta.actualizar_venta_planta();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_observaciones.Text = "";
            txt_cantidad.Text = "";
            txt_subtotal.Text = "";
            txt_codigo_venta.Text = "";
            txt_codigo_planta.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_venta.Text == "")
            {
                MessageBox.Show("Digite el codigo de la venta que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Venta_planta.id_venta_fk_venta_plantaM = long.Parse(txt_codigo_venta.Text);
                obj_Venta_planta.eliminar_venta_planta();
            }
        }
    }
}

