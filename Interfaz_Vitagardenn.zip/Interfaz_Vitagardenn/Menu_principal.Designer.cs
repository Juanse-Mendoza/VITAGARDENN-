﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_Menu_mod_principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Menu_mod_principal));
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_cliente = new System.Windows.Forms.Button();
            this.Btn_compra = new System.Windows.Forms.Button();
            this.Btn_venta = new System.Windows.Forms.Button();
            this.Btn_proveedor = new System.Windows.Forms.Button();
            this.Btn_usuario = new System.Windows.Forms.Button();
            this.Btn_empleado = new System.Windows.Forms.Button();
            this.Btn_entrada_planta = new System.Windows.Forms.Button();
            this.Btn_salida_producto = new System.Windows.Forms.Button();
            this.Btn_entrada_compra = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(16, 26);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 2;
            this.Ptb_titulo.TabStop = false;
            this.Ptb_titulo.Click += new System.EventHandler(this.Ptb_titulo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(121, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 33);
            this.label1.TabIndex = 3;
            this.label1.Text = "MÓDULOS PRINCIPALES";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(68, 70);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 57);
            this.label2.TabIndex = 4;
            this.label2.Text = "|";
            // 
            // Btn_cliente
            // 
            this.Btn_cliente.BackColor = System.Drawing.Color.White;
            this.Btn_cliente.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cliente.Location = new System.Drawing.Point(16, 174);
            this.Btn_cliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_cliente.Name = "Btn_cliente";
            this.Btn_cliente.Size = new System.Drawing.Size(295, 103);
            this.Btn_cliente.TabIndex = 5;
            this.Btn_cliente.Text = "CLIENTE";
            this.Btn_cliente.UseVisualStyleBackColor = false;
            this.Btn_cliente.Click += new System.EventHandler(this.Btn_cliente_Click);
            // 
            // Btn_compra
            // 
            this.Btn_compra.BackColor = System.Drawing.Color.White;
            this.Btn_compra.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_compra.Location = new System.Drawing.Point(387, 174);
            this.Btn_compra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_compra.Name = "Btn_compra";
            this.Btn_compra.Size = new System.Drawing.Size(295, 103);
            this.Btn_compra.TabIndex = 6;
            this.Btn_compra.Text = "COMPRA";
            this.Btn_compra.UseVisualStyleBackColor = false;
            this.Btn_compra.Click += new System.EventHandler(this.Btn_compra_Click);
            // 
            // Btn_venta
            // 
            this.Btn_venta.BackColor = System.Drawing.Color.White;
            this.Btn_venta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_venta.Location = new System.Drawing.Point(744, 174);
            this.Btn_venta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_venta.Name = "Btn_venta";
            this.Btn_venta.Size = new System.Drawing.Size(295, 103);
            this.Btn_venta.TabIndex = 7;
            this.Btn_venta.Text = "VENTA";
            this.Btn_venta.UseVisualStyleBackColor = false;
            this.Btn_venta.Click += new System.EventHandler(this.Btn_venta_Click);
            // 
            // Btn_proveedor
            // 
            this.Btn_proveedor.BackColor = System.Drawing.Color.White;
            this.Btn_proveedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_proveedor.Location = new System.Drawing.Point(744, 326);
            this.Btn_proveedor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_proveedor.Name = "Btn_proveedor";
            this.Btn_proveedor.Size = new System.Drawing.Size(295, 103);
            this.Btn_proveedor.TabIndex = 10;
            this.Btn_proveedor.Text = "PROVEEDOR";
            this.Btn_proveedor.UseVisualStyleBackColor = false;
            this.Btn_proveedor.Click += new System.EventHandler(this.Btn_proveedor_Click);
            // 
            // Btn_usuario
            // 
            this.Btn_usuario.BackColor = System.Drawing.Color.White;
            this.Btn_usuario.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_usuario.Location = new System.Drawing.Point(387, 326);
            this.Btn_usuario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_usuario.Name = "Btn_usuario";
            this.Btn_usuario.Size = new System.Drawing.Size(295, 103);
            this.Btn_usuario.TabIndex = 9;
            this.Btn_usuario.Text = "USUARIO";
            this.Btn_usuario.UseVisualStyleBackColor = false;
            this.Btn_usuario.Click += new System.EventHandler(this.Btn_usuario_Click);
            // 
            // Btn_empleado
            // 
            this.Btn_empleado.BackColor = System.Drawing.Color.White;
            this.Btn_empleado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_empleado.Location = new System.Drawing.Point(16, 326);
            this.Btn_empleado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_empleado.Name = "Btn_empleado";
            this.Btn_empleado.Size = new System.Drawing.Size(295, 103);
            this.Btn_empleado.TabIndex = 8;
            this.Btn_empleado.Text = "EMPLEADO";
            this.Btn_empleado.UseVisualStyleBackColor = false;
            this.Btn_empleado.Click += new System.EventHandler(this.Btn_empleado_Click);
            // 
            // Btn_entrada_planta
            // 
            this.Btn_entrada_planta.BackColor = System.Drawing.Color.White;
            this.Btn_entrada_planta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_entrada_planta.Location = new System.Drawing.Point(744, 485);
            this.Btn_entrada_planta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_entrada_planta.Name = "Btn_entrada_planta";
            this.Btn_entrada_planta.Size = new System.Drawing.Size(295, 103);
            this.Btn_entrada_planta.TabIndex = 13;
            this.Btn_entrada_planta.Text = "ENTRADA PLANTA";
            this.Btn_entrada_planta.UseVisualStyleBackColor = false;
            this.Btn_entrada_planta.Click += new System.EventHandler(this.button6_Click);
            // 
            // Btn_salida_producto
            // 
            this.Btn_salida_producto.BackColor = System.Drawing.Color.White;
            this.Btn_salida_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_salida_producto.Location = new System.Drawing.Point(387, 485);
            this.Btn_salida_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_salida_producto.Name = "Btn_salida_producto";
            this.Btn_salida_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_salida_producto.TabIndex = 12;
            this.Btn_salida_producto.Text = "SALIDA PRODUCTO";
            this.Btn_salida_producto.UseVisualStyleBackColor = false;
            this.Btn_salida_producto.Click += new System.EventHandler(this.button7_Click);
            // 
            // Btn_entrada_compra
            // 
            this.Btn_entrada_compra.BackColor = System.Drawing.Color.White;
            this.Btn_entrada_compra.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_entrada_compra.Location = new System.Drawing.Point(16, 485);
            this.Btn_entrada_compra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_entrada_compra.Name = "Btn_entrada_compra";
            this.Btn_entrada_compra.Size = new System.Drawing.Size(295, 103);
            this.Btn_entrada_compra.TabIndex = 11;
            this.Btn_entrada_compra.Text = "ENTRADA COMPRA";
            this.Btn_entrada_compra.UseVisualStyleBackColor = false;
            this.Btn_entrada_compra.Click += new System.EventHandler(this.button8_Click);
            // 
            // Frm_Menu_mod_principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.descarga;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1072, 647);
            this.Controls.Add(this.Btn_entrada_planta);
            this.Controls.Add(this.Btn_salida_producto);
            this.Controls.Add(this.Btn_entrada_compra);
            this.Controls.Add(this.Btn_proveedor);
            this.Controls.Add(this.Btn_usuario);
            this.Controls.Add(this.Btn_empleado);
            this.Controls.Add(this.Btn_venta);
            this.Controls.Add(this.Btn_compra);
            this.Controls.Add(this.Btn_cliente);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ptb_titulo);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frm_Menu_mod_principal";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Menú Módulos Principales";
            this.Load += new System.EventHandler(this.Menu_principal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_cliente;
        private System.Windows.Forms.Button Btn_compra;
        private System.Windows.Forms.Button Btn_venta;
        private System.Windows.Forms.Button Btn_proveedor;
        private System.Windows.Forms.Button Btn_usuario;
        private System.Windows.Forms.Button Btn_empleado;
        private System.Windows.Forms.Button Btn_entrada_planta;
        private System.Windows.Forms.Button Btn_salida_producto;
        private System.Windows.Forms.Button Btn_entrada_compra;
    }
}