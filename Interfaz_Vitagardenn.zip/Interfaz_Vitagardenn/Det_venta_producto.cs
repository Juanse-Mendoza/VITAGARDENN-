﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Det_venta_producto : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_detalle_venta_producto obj_Venta_producto = new Clase_detalle_venta_producto();
        public Frm_Det_venta_producto()
        {
            InitializeComponent();
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void txt_codigo_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_venta_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Venta_producto.observaciones_venta_productoM = txt_observaciones.Text;
            obj_Venta_producto.cantidadM = int.Parse(txt_cantidad.Text);
            obj_Venta_producto.valorM = float.Parse(txt_valor.Text);
            obj_Venta_producto.id_producto_fk_venta_productoM = long.Parse(txt_codigo_producto.Text);
            obj_Venta_producto.id_venta_fk_venta_productoM = long.Parse(txt_codigo_venta.Text);
            obj_Venta_producto.insertar_venta_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Venta_producto.Consultageneral_venta_producto(ref dgv_Det_venta_producto);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles detalles = new frm_Menu_detalles();
            detalles.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_producto.Text == "")
            {
                MessageBox.Show("Digite el codigo del producto que desea actualizar");
            }
            else if (txt_codigo_producto.Text != "")
            {
                obj_Venta_producto.observaciones_venta_productoM = txt_observaciones.Text;
                obj_Venta_producto.cantidadM = int.Parse(txt_cantidad.Text);
                obj_Venta_producto.valorM = float.Parse(txt_valor.Text);
                obj_Venta_producto.id_producto_fk_venta_productoM = long.Parse(txt_codigo_producto.Text);
                obj_Venta_producto.id_venta_fk_venta_productoM = long.Parse(txt_codigo_venta.Text);
                obj_Venta_producto.actualizar_venta_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_observaciones.Text = "";
            txt_cantidad.Text = "";
            txt_valor.Text = "";
            txt_codigo_producto.Text = "";
            txt_codigo_venta.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_producto.Text == "")
            {
                MessageBox.Show("Digite el codigo del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Venta_producto.id_producto_fk_venta_productoM = long.Parse(txt_codigo_producto.Text);
                obj_Venta_producto.eliminar_venta_producto();
            }
        }

        private void Frm_Det_venta_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
