﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_cliente));
            this.pnl_izquierda = new System.Windows.Forms.Panel();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.btn_consultar = new System.Windows.Forms.Button();
            this.btn_crear = new System.Windows.Forms.Button();
            this.Pnl_arriba = new System.Windows.Forms.Panel();
            this.lB_TITULO = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.txt_codigo_empleado = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lb_codigo_empleado = new System.Windows.Forms.Label();
            this.lb_email = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.lb_nombre = new System.Windows.Forms.Label();
            this.lb_codigo = new System.Windows.Forms.Label();
            this.dgv_cliente = new System.Windows.Forms.DataGridView();
            this.lb_estado = new System.Windows.Forms.Label();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.pnl_izquierda.SuspendLayout();
            this.Pnl_arriba.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cliente)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_izquierda
            // 
            this.pnl_izquierda.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green1;
            this.pnl_izquierda.Controls.Add(this.Btn_eliminar);
            this.pnl_izquierda.Controls.Add(this.btn_modificar);
            this.pnl_izquierda.Controls.Add(this.btn_volver);
            this.pnl_izquierda.Controls.Add(this.btn_consultar);
            this.pnl_izquierda.Controls.Add(this.btn_crear);
            this.pnl_izquierda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_izquierda.Location = new System.Drawing.Point(0, 110);
            this.pnl_izquierda.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_izquierda.Name = "pnl_izquierda";
            this.pnl_izquierda.Size = new System.Drawing.Size(267, 508);
            this.pnl_izquierda.TabIndex = 24;
            this.pnl_izquierda.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_izquierda_Paint);
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_eliminar.Location = new System.Drawing.Point(39, 308);
            this.Btn_eliminar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(203, 54);
            this.Btn_eliminar.TabIndex = 78;
            this.Btn_eliminar.Text = "ELIMINAR";
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            this.Btn_eliminar.Click += new System.EventHandler(this.Btn_eliminar_Click);
            // 
            // btn_modificar
            // 
            this.btn_modificar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modificar.Location = new System.Drawing.Point(39, 218);
            this.btn_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(203, 54);
            this.btn_modificar.TabIndex = 77;
            this.btn_modificar.Text = "MODIFICAR";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.Location = new System.Drawing.Point(39, 402);
            this.btn_volver.Margin = new System.Windows.Forms.Padding(4);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(203, 54);
            this.btn_volver.TabIndex = 75;
            this.btn_volver.Text = "VOLVER";
            this.btn_volver.UseVisualStyleBackColor = true;
            this.btn_volver.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_consultar
            // 
            this.btn_consultar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultar.Location = new System.Drawing.Point(39, 137);
            this.btn_consultar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_consultar.Name = "btn_consultar";
            this.btn_consultar.Size = new System.Drawing.Size(203, 54);
            this.btn_consultar.TabIndex = 76;
            this.btn_consultar.Text = "CONSULTAR";
            this.btn_consultar.UseVisualStyleBackColor = true;
            this.btn_consultar.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_crear
            // 
            this.btn_crear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_crear.Location = new System.Drawing.Point(39, 43);
            this.btn_crear.Margin = new System.Windows.Forms.Padding(4);
            this.btn_crear.Name = "btn_crear";
            this.btn_crear.Size = new System.Drawing.Size(203, 54);
            this.btn_crear.TabIndex = 74;
            this.btn_crear.Text = "CREAR";
            this.btn_crear.UseVisualStyleBackColor = true;
            this.btn_crear.Click += new System.EventHandler(this.button1_Click);
            // 
            // Pnl_arriba
            // 
            this.Pnl_arriba.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.green3;
            this.Pnl_arriba.Controls.Add(this.lB_TITULO);
            this.Pnl_arriba.Controls.Add(this.Ptb_titulo);
            this.Pnl_arriba.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_arriba.Location = new System.Drawing.Point(0, 0);
            this.Pnl_arriba.Margin = new System.Windows.Forms.Padding(4);
            this.Pnl_arriba.Name = "Pnl_arriba";
            this.Pnl_arriba.Size = new System.Drawing.Size(1067, 110);
            this.Pnl_arriba.TabIndex = 23;
            // 
            // lB_TITULO
            // 
            this.lB_TITULO.AutoSize = true;
            this.lB_TITULO.BackColor = System.Drawing.Color.Transparent;
            this.lB_TITULO.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lB_TITULO.ForeColor = System.Drawing.Color.White;
            this.lB_TITULO.Location = new System.Drawing.Point(48, 55);
            this.lB_TITULO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lB_TITULO.Name = "lB_TITULO";
            this.lB_TITULO.Size = new System.Drawing.Size(114, 33);
            this.lB_TITULO.TabIndex = 6;
            this.lB_TITULO.Text = "CLIENTE";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(25, 15);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            // 
            // txt_codigo_empleado
            // 
            this.txt_codigo_empleado.Location = new System.Drawing.Point(640, 347);
            this.txt_codigo_empleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo_empleado.Name = "txt_codigo_empleado";
            this.txt_codigo_empleado.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo_empleado.TabIndex = 32;
            this.txt_codigo_empleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_empleado_KeyPress_1);
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(640, 263);
            this.txt_email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(187, 22);
            this.txt_email.TabIndex = 31;
            this.txt_email.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_email_KeyPress);
            // 
            // lb_codigo_empleado
            // 
            this.lb_codigo_empleado.AutoSize = true;
            this.lb_codigo_empleado.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo_empleado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo_empleado.ForeColor = System.Drawing.Color.White;
            this.lb_codigo_empleado.Location = new System.Drawing.Point(468, 347);
            this.lb_codigo_empleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo_empleado.Name = "lb_codigo_empleado";
            this.lb_codigo_empleado.Size = new System.Drawing.Size(157, 23);
            this.lb_codigo_empleado.TabIndex = 30;
            this.lb_codigo_empleado.Text = "Código Empleado";
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.BackColor = System.Drawing.Color.Transparent;
            this.lb_email.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email.ForeColor = System.Drawing.Color.White;
            this.lb_email.Location = new System.Drawing.Point(571, 263);
            this.lb_email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(54, 23);
            this.lb_email.TabIndex = 29;
            this.lb_email.Text = "Email";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(640, 215);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(187, 22);
            this.txt_nombre.TabIndex = 28;
            this.txt_nombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_nombre_KeyPress_1);
            // 
            // txt_codigo
            // 
            this.txt_codigo.Location = new System.Drawing.Point(640, 164);
            this.txt_codigo.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo.TabIndex = 27;
            this.txt_codigo.TextChanged += new System.EventHandler(this.txt_codigo_TextChanged);
            this.txt_codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_KeyPress_1);
            // 
            // lb_nombre
            // 
            this.lb_nombre.AutoSize = true;
            this.lb_nombre.BackColor = System.Drawing.Color.Transparent;
            this.lb_nombre.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nombre.ForeColor = System.Drawing.Color.White;
            this.lb_nombre.Location = new System.Drawing.Point(489, 214);
            this.lb_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_nombre.Name = "lb_nombre";
            this.lb_nombre.Size = new System.Drawing.Size(140, 23);
            this.lb_nombre.TabIndex = 26;
            this.lb_nombre.Text = "Nombre Cliente";
            // 
            // lb_codigo
            // 
            this.lb_codigo.AutoSize = true;
            this.lb_codigo.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo.ForeColor = System.Drawing.Color.White;
            this.lb_codigo.Location = new System.Drawing.Point(505, 162);
            this.lb_codigo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo.Name = "lb_codigo";
            this.lb_codigo.Size = new System.Drawing.Size(132, 23);
            this.lb_codigo.TabIndex = 25;
            this.lb_codigo.Text = "Código Cliente";
            // 
            // dgv_cliente
            // 
            this.dgv_cliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cliente.Location = new System.Drawing.Point(372, 388);
            this.dgv_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_cliente.Name = "dgv_cliente";
            this.dgv_cliente.RowHeadersWidth = 51;
            this.dgv_cliente.Size = new System.Drawing.Size(591, 185);
            this.dgv_cliente.TabIndex = 33;
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.BackColor = System.Drawing.Color.Transparent;
            this.lb_estado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_estado.ForeColor = System.Drawing.Color.White;
            this.lb_estado.Location = new System.Drawing.Point(571, 304);
            this.lb_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(64, 23);
            this.lb_estado.TabIndex = 34;
            this.lb_estado.Text = "Estado";
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(640, 305);
            this.txt_estado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(187, 22);
            this.txt_estado.TabIndex = 35;
            this.txt_estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_estado_KeyPress);
            // 
            // Frm_cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green22;
            this.ClientSize = new System.Drawing.Size(1067, 618);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.lb_estado);
            this.Controls.Add(this.dgv_cliente);
            this.Controls.Add(this.txt_codigo_empleado);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.lb_codigo_empleado);
            this.Controls.Add(this.lb_email);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.lb_nombre);
            this.Controls.Add(this.lb_codigo);
            this.Controls.Add(this.pnl_izquierda);
            this.Controls.Add(this.Pnl_arriba);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_cliente";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Cliente";
            this.pnl_izquierda.ResumeLayout(false);
            this.Pnl_arriba.ResumeLayout(false);
            this.Pnl_arriba.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_izquierda;
        private System.Windows.Forms.Panel Pnl_arriba;
        private System.Windows.Forms.TextBox txt_codigo_empleado;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lb_codigo_empleado;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label lb_nombre;
        private System.Windows.Forms.Label lb_codigo;
        private System.Windows.Forms.DataGridView dgv_cliente;
        private System.Windows.Forms.Label lB_TITULO;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Button btn_volver;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_crear;
        private System.Windows.Forms.Button btn_consultar;
        private System.Windows.Forms.Label lb_estado;
        private System.Windows.Forms.TextBox txt_estado;
    }
}