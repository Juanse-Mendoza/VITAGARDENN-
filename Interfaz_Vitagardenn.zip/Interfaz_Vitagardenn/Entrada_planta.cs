﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class frm_Entrada_planta : Form
    {

        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_entrada_planta obj_Entrada_planta = new Clase_entrada_planta();
        public frm_Entrada_planta()
        {
            InitializeComponent();
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void pnl_izquierda_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Entrada_planta.observacionesM = txt_observaciones.Text;
            obj_Entrada_planta.cantidadM = int.Parse(txt_cantidad.Text);
            obj_Entrada_planta.id_entrada_compra_fk_entrada_plantaM = long.Parse(txt_codigo_entrada_compra.Text);
            obj_Entrada_planta.id_planta_fk_entrada_plantaM = long.Parse(txt_codigo_planta.Text);
            obj_Entrada_planta.insertar_entrada_planta();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Entrada_planta.Consultageneral_entrada_planta(ref dgv_entrada_planta);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if(txt_codigo_planta.Text == "")
            {
                MessageBox.Show("Digite el codigo de la planta que desea actualizar");
            }
            else if (txt_codigo_planta.Text != "")
            {
                obj_Entrada_planta.observacionesM = txt_observaciones.Text;
                obj_Entrada_planta.cantidadM = int.Parse(txt_cantidad.Text);
                obj_Entrada_planta.id_entrada_compra_fk_entrada_plantaM = long.Parse(txt_codigo_entrada_compra.Text);
                obj_Entrada_planta.id_planta_fk_entrada_plantaM = long.Parse(txt_codigo_planta.Text);
                obj_Entrada_planta.actualizar_entrada_planta();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_observaciones.Text = "";
            txt_cantidad.Text = "";
            txt_codigo_entrada_compra.Text = "";
            txt_codigo_planta.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
                if (txt_codigo_planta.Text == "")
                {
                    MessageBox.Show("Digite el codigo de la planta que desea eliminar");
                }
                else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    obj_Entrada_planta.id_planta_fk_entrada_plantaM = long.Parse(txt_codigo_planta.Text);
                    obj_Entrada_planta.eliminar_entrada_planta();
                }
        }

        private void txt_codigo_entrada_compra_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_planta_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
