﻿
namespace Vitagardenn_interfaz
{
    partial class frm_Menu_detalles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Menu_detalles));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.Btn_d_venta_planta = new System.Windows.Forms.Button();
            this.Btn_d_venta_producto = new System.Windows.Forms.Button();
            this.Btn_d_entrada_compra_producto = new System.Windows.Forms.Button();
            this.Btn_d_compra_producto = new System.Windows.Forms.Button();
            this.Btn_d_salida_inventario_producto = new System.Windows.Forms.Button();
            this.Btn_d_salida_planta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(71, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 57);
            this.label2.TabIndex = 7;
            this.label2.Text = "|";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(124, 86);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 33);
            this.label1.TabIndex = 6;
            this.label1.Text = "DETALLES";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(19, 22);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            this.Ptb_titulo.Click += new System.EventHandler(this.Ptb_titulo_Click);
            // 
            // Btn_d_venta_planta
            // 
            this.Btn_d_venta_planta.BackColor = System.Drawing.Color.White;
            this.Btn_d_venta_planta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_venta_planta.Location = new System.Drawing.Point(53, 181);
            this.Btn_d_venta_planta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_venta_planta.Name = "Btn_d_venta_planta";
            this.Btn_d_venta_planta.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_venta_planta.TabIndex = 8;
            this.Btn_d_venta_planta.Text = "D. VENTA-PLANTA";
            this.Btn_d_venta_planta.UseVisualStyleBackColor = false;
            this.Btn_d_venta_planta.Click += new System.EventHandler(this.Btn_d_venta_planta_Click);
            // 
            // Btn_d_venta_producto
            // 
            this.Btn_d_venta_producto.BackColor = System.Drawing.Color.White;
            this.Btn_d_venta_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_venta_producto.Location = new System.Drawing.Point(408, 181);
            this.Btn_d_venta_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_venta_producto.Name = "Btn_d_venta_producto";
            this.Btn_d_venta_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_venta_producto.TabIndex = 9;
            this.Btn_d_venta_producto.Text = "D. VENTA-PRODUCTO";
            this.Btn_d_venta_producto.UseVisualStyleBackColor = false;
            this.Btn_d_venta_producto.Click += new System.EventHandler(this.Btn_d_venta_producto_Click);
            // 
            // Btn_d_entrada_compra_producto
            // 
            this.Btn_d_entrada_compra_producto.BackColor = System.Drawing.Color.White;
            this.Btn_d_entrada_compra_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_entrada_compra_producto.Location = new System.Drawing.Point(755, 181);
            this.Btn_d_entrada_compra_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_entrada_compra_producto.Name = "Btn_d_entrada_compra_producto";
            this.Btn_d_entrada_compra_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_entrada_compra_producto.TabIndex = 10;
            this.Btn_d_entrada_compra_producto.Text = "D. ENTRADA COMPRA-PRODUCTO";
            this.Btn_d_entrada_compra_producto.UseVisualStyleBackColor = false;
            this.Btn_d_entrada_compra_producto.Click += new System.EventHandler(this.Btn_d_entrada_compra_producto_Click);
            // 
            // Btn_d_compra_producto
            // 
            this.Btn_d_compra_producto.BackColor = System.Drawing.Color.White;
            this.Btn_d_compra_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_compra_producto.Location = new System.Drawing.Point(53, 334);
            this.Btn_d_compra_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_compra_producto.Name = "Btn_d_compra_producto";
            this.Btn_d_compra_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_compra_producto.TabIndex = 11;
            this.Btn_d_compra_producto.Text = "D. COMPRA-PRODUCTO";
            this.Btn_d_compra_producto.UseVisualStyleBackColor = false;
            this.Btn_d_compra_producto.Click += new System.EventHandler(this.Btn_d_compra_producto_Click);
            // 
            // Btn_d_salida_inventario_producto
            // 
            this.Btn_d_salida_inventario_producto.BackColor = System.Drawing.Color.White;
            this.Btn_d_salida_inventario_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_salida_inventario_producto.Location = new System.Drawing.Point(408, 334);
            this.Btn_d_salida_inventario_producto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_salida_inventario_producto.Name = "Btn_d_salida_inventario_producto";
            this.Btn_d_salida_inventario_producto.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_salida_inventario_producto.TabIndex = 12;
            this.Btn_d_salida_inventario_producto.Text = "D. SALIDA INVENTARIO-PRODUCTO";
            this.Btn_d_salida_inventario_producto.UseVisualStyleBackColor = false;
            this.Btn_d_salida_inventario_producto.Click += new System.EventHandler(this.Btn_d_salida_inventario_producto_Click);
            // 
            // Btn_d_salida_planta
            // 
            this.Btn_d_salida_planta.BackColor = System.Drawing.Color.White;
            this.Btn_d_salida_planta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_d_salida_planta.Location = new System.Drawing.Point(755, 334);
            this.Btn_d_salida_planta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Btn_d_salida_planta.Name = "Btn_d_salida_planta";
            this.Btn_d_salida_planta.Size = new System.Drawing.Size(295, 103);
            this.Btn_d_salida_planta.TabIndex = 13;
            this.Btn_d_salida_planta.Text = "D. SALIDA-PLANTA";
            this.Btn_d_salida_planta.UseVisualStyleBackColor = false;
            this.Btn_d_salida_planta.Click += new System.EventHandler(this.Btn_d_salida_planta_Click);
            // 
            // frm_Menu_detalles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.image3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1104, 624);
            this.Controls.Add(this.Btn_d_salida_planta);
            this.Controls.Add(this.Btn_d_salida_inventario_producto);
            this.Controls.Add(this.Btn_d_compra_producto);
            this.Controls.Add(this.Btn_d_entrada_compra_producto);
            this.Controls.Add(this.Btn_d_venta_producto);
            this.Controls.Add(this.Btn_d_venta_planta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ptb_titulo);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frm_Menu_detalles";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Menú Detalles";
            this.Load += new System.EventHandler(this.Menu_detalles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_d_venta_planta;
        private System.Windows.Forms.Button Btn_d_venta_producto;
        private System.Windows.Forms.Button Btn_d_entrada_compra_producto;
        private System.Windows.Forms.Button Btn_d_compra_producto;
        private System.Windows.Forms.Button Btn_d_salida_inventario_producto;
        private System.Windows.Forms.Button Btn_d_salida_planta;
    }
}