﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_Inicio
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Inicio));
            this.Btn_iniciar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_iniciar
            // 
            this.Btn_iniciar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btn_iniciar.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_iniciar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_iniciar.Location = new System.Drawing.Point(318, 374);
            this.Btn_iniciar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn_iniciar.Name = "Btn_iniciar";
            this.Btn_iniciar.Size = new System.Drawing.Size(116, 58);
            this.Btn_iniciar.TabIndex = 1;
            this.Btn_iniciar.Text = "INICIAR";
            this.Btn_iniciar.UseVisualStyleBackColor = false;
            this.Btn_iniciar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Frm_Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Pantallazo_2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(778, 513);
            this.Controls.Add(this.Btn_iniciar);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_Inicio";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Inicio";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Btn_iniciar;
    }
}

