﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Compra : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_compra obj_Compra = new Clase_compra();
        public Frm_Compra()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {
        }

        private void txt_codigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_email_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_codigo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cantidad_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_email_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Compra.Consultageneral_compra(ref dgv_compra);
        }

        private void ptb_crear_Click_1(object sender, EventArgs e)
        {
            obj_Compra.id_compraM = long.Parse(txt_codigo.Text);
            obj_Compra.cantidad_compraM = int.Parse(txt_cantidad.Text);
            obj_Compra.valor_compraM = (float)double.Parse(txt_valor.Text);
            obj_Compra.estadoM = txt_estado.Text;
            obj_Compra.id_empleado_fk_compraM = long.Parse(txt_codigo_empleado.Text);
            obj_Compra.id_proveedor_fk_compraM = long.Parse(txt_codigo_proveedor.Text);
            obj_Compra.insertar_compra();
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Compra.id_compraM = long.Parse(txt_codigo.Text);
            obj_Compra.cantidad_compraM = int.Parse(txt_cantidad.Text);
            obj_Compra.valor_compraM = (float)double.Parse(txt_valor.Text);
            obj_Compra.estadoM = txt_estado.Text;
            obj_Compra.id_empleado_fk_compraM = long.Parse(txt_codigo_empleado.Text);
            obj_Compra.id_proveedor_fk_compraM = long.Parse(txt_codigo_proveedor.Text);
            obj_Compra.insertar_compra();
        }

        private void lb_consulta_Click(object sender, EventArgs e)
        {

        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Compra.Consultageneral_compra(ref dgv_compra);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la compra que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Compra.id_compraM = long.Parse(txt_codigo.Text);
                obj_Compra.cantidad_compraM = int.Parse(txt_cantidad.Text);
                obj_Compra.valor_compraM = (float)double.Parse(txt_valor.Text);
                obj_Compra.estadoM = txt_estado.Text;
                obj_Compra.id_empleado_fk_compraM = long.Parse(txt_codigo_empleado.Text);
                obj_Compra.id_proveedor_fk_compraM = long.Parse(txt_codigo_proveedor.Text);
                obj_Compra.actualizar_compra();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_cantidad.Text = "";
            txt_valor.Text = "";
            txt_estado.Text = "";
            txt_codigo_empleado.Text = "";
            txt_codigo_proveedor.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la compra que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Compra.id_compraM = long.Parse(txt_codigo.Text);
                obj_Compra.eliminar_compra();
            }
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_codigo_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_proveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}