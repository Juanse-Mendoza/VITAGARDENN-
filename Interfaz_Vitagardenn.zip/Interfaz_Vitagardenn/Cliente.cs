﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_cliente : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_cliente obj_Cliente = new Clase_cliente();
        public Frm_cliente()
        {
            InitializeComponent();
        }

        private void ptb_volver_Click(object sender, EventArgs e)
        {

        }

        private void lb_volver_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_codigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_codigo_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {
            obj_Cliente.id_clienteM = long.Parse(txt_codigo.Text);
            obj_Cliente.email_clienteM = txt_email.Text;
            obj_Cliente.nombre_clienteM = txt_nombre.Text;
            obj_Cliente.id_empleado_fk_clienteM = long.Parse(txt_codigo_empleado.Text);
            obj_Cliente.insertar_cliente();
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void txt_codigo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_nombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_email_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txt_codigo_empleado_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void lb_consulta_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            obj_Cliente.id_clienteM = long.Parse(txt_codigo.Text);
            obj_Cliente.email_clienteM = txt_email.Text;
            obj_Cliente.nombre_clienteM = txt_nombre.Text;
            obj_Cliente.estado_clienteM = txt_estado.Text;
            obj_Cliente.id_empleado_fk_clienteM = long.Parse(txt_codigo_empleado.Text);
            obj_Cliente.insertar_cliente();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            obj_Cliente.Consultageneral_cliente(ref dgv_cliente);
        }

        private void lb_modificar_Click(object sender, EventArgs e)
        {

        }

        private void ptb_modificar_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void pnl_izquierda_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del cliente que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Cliente.id_clienteM = long.Parse(txt_codigo.Text);
                obj_Cliente.email_clienteM = txt_email.Text;
                obj_Cliente.nombre_clienteM = txt_nombre.Text;
                obj_Cliente.estado_clienteM = txt_estado.Text;
                obj_Cliente.id_empleado_fk_clienteM = long.Parse(txt_codigo_empleado.Text);
                obj_Cliente.actualizar_cliente();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_email.Text = "";
            txt_estado.Text = "";
            txt_codigo_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del cliente que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Cliente.id_clienteM = long.Parse(txt_codigo.Text);
                obj_Cliente.eliminar_cliente();
            }
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }
    }
}

