﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vitagardenn_interfaz.Reportes;

namespace Vitagardenn_interfaz
{
    public partial class frm_Menu_Factura : Form
    {
        public frm_Menu_Factura()
        {
            InitializeComponent();
        }

        private void Ptb_titulo_Click(object sender, EventArgs e)
        {
            frm_Menu_priincipal priincipal= new frm_Menu_priincipal();
            priincipal.Show();
            this.Hide();
        }

        private void Btn_planta_Click(object sender, EventArgs e)
        {
            frm_reporte_planta planta = new frm_reporte_planta();
            planta.Show();
            this.Hide();
        }

        private void Btn_factura_Click(object sender, EventArgs e)
        {
            frm_reporte_facturacs factura = new frm_reporte_facturacs();
            factura.Show();
            this.Hide();
        }

        private void Btn_producto_Click(object sender, EventArgs e)
        {
            frm_reporte_producto producto = new frm_reporte_producto();
            producto.Show();
            this.Hide();
        }

        private void btn_reporte_Click(object sender, EventArgs e)
        {

        }
    }
}
