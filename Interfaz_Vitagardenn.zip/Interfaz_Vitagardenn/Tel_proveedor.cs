﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Tel_proveedor : Form
    {
        LOGICA.Clase_telefono_proveedor obj_Telefono_proveedor = new Clase_telefono_proveedor();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Tel_proveedor()
        {
            InitializeComponent();
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Telefono_proveedor.Consultageneral_tel_proveedor(ref dgv_tel_proveedor);
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

            
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {
   
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Telefono_proveedor.id_telefono_proveedorM = long.Parse(txt_codigo.Text);
            obj_Telefono_proveedor.numero_telefono_proveedorM = int.Parse(txt_numero.Text);
            obj_Telefono_proveedor.id_proveedor_fk_telefono_proveedorM = long.Parse(txt_codigo_proveedor.Text);
            obj_Telefono_proveedor.insertar_telefono_proveedor();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Telefono_proveedor.Consultageneral_tel_proveedor(ref dgv_tel_proveedor);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_telefonos telefonos = new frm_Menu_telefonos();
            telefonos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono del proveedor que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Telefono_proveedor.id_telefono_proveedorM = long.Parse(txt_codigo.Text);
                obj_Telefono_proveedor.numero_telefono_proveedorM = int.Parse(txt_numero.Text);
                obj_Telefono_proveedor.id_proveedor_fk_telefono_proveedorM = long.Parse(txt_codigo_proveedor.Text);
                obj_Telefono_proveedor.actualizar_telefono_proveedor();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_numero.Text = "";
            txt_codigo_proveedor.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono del proveedor que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Telefono_proveedor.id_telefono_proveedorM = long.Parse(txt_codigo.Text);
                obj_Telefono_proveedor.eliminar_telefono_proveedor();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_numero_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_proveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
