﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_entrada_compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_entrada_compra));
            this.pnl_izquierda = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Btn_volver = new System.Windows.Forms.Button();
            this.Btn_modificar = new System.Windows.Forms.Button();
            this.Btn_crear = new System.Windows.Forms.Button();
            this.Btn_consultar = new System.Windows.Forms.Button();
            this.Pnl_arriba = new System.Windows.Forms.Panel();
            this.lB_TITULO = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.Lb_codigo_empleado = new System.Windows.Forms.Label();
            this.Lb_codigo_compra = new System.Windows.Forms.Label();
            this.Lb_estado = new System.Windows.Forms.Label();
            this.lb_fecha = new System.Windows.Forms.Label();
            this.txt_codigo_empleado = new System.Windows.Forms.TextBox();
            this.txt_codigo_compra = new System.Windows.Forms.TextBox();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.txt_fecha = new System.Windows.Forms.TextBox();
            this.dgv_entrada_compra = new System.Windows.Forms.DataGridView();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.lb_codigo = new System.Windows.Forms.Label();
            this.pnl_izquierda.SuspendLayout();
            this.Pnl_arriba.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_entrada_compra)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_izquierda
            // 
            this.pnl_izquierda.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green1;
            this.pnl_izquierda.Controls.Add(this.panel1);
            this.pnl_izquierda.Controls.Add(this.Btn_eliminar);
            this.pnl_izquierda.Controls.Add(this.Btn_volver);
            this.pnl_izquierda.Controls.Add(this.Btn_modificar);
            this.pnl_izquierda.Controls.Add(this.Btn_crear);
            this.pnl_izquierda.Controls.Add(this.Btn_consultar);
            this.pnl_izquierda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_izquierda.Location = new System.Drawing.Point(0, 110);
            this.pnl_izquierda.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_izquierda.Name = "pnl_izquierda";
            this.pnl_izquierda.Size = new System.Drawing.Size(267, 516);
            this.pnl_izquierda.TabIndex = 46;
            this.pnl_izquierda.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_izquierda_Paint);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(267, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(148, 110);
            this.panel1.TabIndex = 62;
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_eliminar.Location = new System.Drawing.Point(32, 304);
            this.Btn_eliminar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(203, 54);
            this.Btn_eliminar.TabIndex = 73;
            this.Btn_eliminar.Text = "ELIMINAR";
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            this.Btn_eliminar.Click += new System.EventHandler(this.Btn_eliminar_Click);
            // 
            // Btn_volver
            // 
            this.Btn_volver.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_volver.Location = new System.Drawing.Point(32, 391);
            this.Btn_volver.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_volver.Name = "Btn_volver";
            this.Btn_volver.Size = new System.Drawing.Size(203, 54);
            this.Btn_volver.TabIndex = 71;
            this.Btn_volver.Text = "VOLVER";
            this.Btn_volver.UseVisualStyleBackColor = true;
            this.Btn_volver.Click += new System.EventHandler(this.button2_Click);
            // 
            // Btn_modificar
            // 
            this.Btn_modificar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_modificar.Location = new System.Drawing.Point(32, 225);
            this.Btn_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_modificar.Name = "Btn_modificar";
            this.Btn_modificar.Size = new System.Drawing.Size(203, 54);
            this.Btn_modificar.TabIndex = 72;
            this.Btn_modificar.Text = "MODIFICAR";
            this.Btn_modificar.UseVisualStyleBackColor = true;
            this.Btn_modificar.Click += new System.EventHandler(this.Btn_modificar_Click);
            // 
            // Btn_crear
            // 
            this.Btn_crear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_crear.Location = new System.Drawing.Point(32, 50);
            this.Btn_crear.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_crear.Name = "Btn_crear";
            this.Btn_crear.Size = new System.Drawing.Size(203, 54);
            this.Btn_crear.TabIndex = 62;
            this.Btn_crear.Text = "CREAR";
            this.Btn_crear.UseVisualStyleBackColor = true;
            this.Btn_crear.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btn_consultar
            // 
            this.Btn_consultar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_consultar.Location = new System.Drawing.Point(32, 133);
            this.Btn_consultar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_consultar.Name = "Btn_consultar";
            this.Btn_consultar.Size = new System.Drawing.Size(203, 54);
            this.Btn_consultar.TabIndex = 71;
            this.Btn_consultar.Text = "CONSULTAR";
            this.Btn_consultar.UseVisualStyleBackColor = true;
            this.Btn_consultar.Click += new System.EventHandler(this.Btn_consultar_Click);
            // 
            // Pnl_arriba
            // 
            this.Pnl_arriba.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.green3;
            this.Pnl_arriba.Controls.Add(this.lB_TITULO);
            this.Pnl_arriba.Controls.Add(this.Ptb_titulo);
            this.Pnl_arriba.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_arriba.Location = new System.Drawing.Point(0, 0);
            this.Pnl_arriba.Margin = new System.Windows.Forms.Padding(4);
            this.Pnl_arriba.Name = "Pnl_arriba";
            this.Pnl_arriba.Size = new System.Drawing.Size(1073, 110);
            this.Pnl_arriba.TabIndex = 45;
            this.Pnl_arriba.Paint += new System.Windows.Forms.PaintEventHandler(this.Pnl_arriba_Paint);
            // 
            // lB_TITULO
            // 
            this.lB_TITULO.AutoSize = true;
            this.lB_TITULO.BackColor = System.Drawing.Color.Transparent;
            this.lB_TITULO.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lB_TITULO.ForeColor = System.Drawing.Color.White;
            this.lB_TITULO.Location = new System.Drawing.Point(49, 55);
            this.lB_TITULO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lB_TITULO.Name = "lB_TITULO";
            this.lB_TITULO.Size = new System.Drawing.Size(262, 33);
            this.lB_TITULO.TabIndex = 4;
            this.lB_TITULO.Text = "ENTRADA COMPRA";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(27, 15);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 3;
            this.Ptb_titulo.TabStop = false;
            // 
            // Lb_codigo_empleado
            // 
            this.Lb_codigo_empleado.AutoSize = true;
            this.Lb_codigo_empleado.BackColor = System.Drawing.Color.Transparent;
            this.Lb_codigo_empleado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lb_codigo_empleado.ForeColor = System.Drawing.Color.White;
            this.Lb_codigo_empleado.Location = new System.Drawing.Point(509, 354);
            this.Lb_codigo_empleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lb_codigo_empleado.Name = "Lb_codigo_empleado";
            this.Lb_codigo_empleado.Size = new System.Drawing.Size(157, 23);
            this.Lb_codigo_empleado.TabIndex = 72;
            this.Lb_codigo_empleado.Text = "Código Empleado";
            // 
            // Lb_codigo_compra
            // 
            this.Lb_codigo_compra.AutoSize = true;
            this.Lb_codigo_compra.BackColor = System.Drawing.Color.Transparent;
            this.Lb_codigo_compra.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lb_codigo_compra.ForeColor = System.Drawing.Color.White;
            this.Lb_codigo_compra.Location = new System.Drawing.Point(524, 300);
            this.Lb_codigo_compra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lb_codigo_compra.Name = "Lb_codigo_compra";
            this.Lb_codigo_compra.Size = new System.Drawing.Size(139, 23);
            this.Lb_codigo_compra.TabIndex = 71;
            this.Lb_codigo_compra.Text = "Código Compra";
            // 
            // Lb_estado
            // 
            this.Lb_estado.AutoSize = true;
            this.Lb_estado.BackColor = System.Drawing.Color.Transparent;
            this.Lb_estado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lb_estado.ForeColor = System.Drawing.Color.White;
            this.Lb_estado.Location = new System.Drawing.Point(599, 255);
            this.Lb_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lb_estado.Name = "Lb_estado";
            this.Lb_estado.Size = new System.Drawing.Size(64, 23);
            this.Lb_estado.TabIndex = 70;
            this.Lb_estado.Text = "Estado";
            // 
            // lb_fecha
            // 
            this.lb_fecha.AutoSize = true;
            this.lb_fecha.BackColor = System.Drawing.Color.Transparent;
            this.lb_fecha.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fecha.ForeColor = System.Drawing.Color.White;
            this.lb_fecha.Location = new System.Drawing.Point(605, 208);
            this.lb_fecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_fecha.Name = "lb_fecha";
            this.lb_fecha.Size = new System.Drawing.Size(57, 23);
            this.lb_fecha.TabIndex = 69;
            this.lb_fecha.Text = "Fecha";
            // 
            // txt_codigo_empleado
            // 
            this.txt_codigo_empleado.Location = new System.Drawing.Point(680, 353);
            this.txt_codigo_empleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo_empleado.Name = "txt_codigo_empleado";
            this.txt_codigo_empleado.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo_empleado.TabIndex = 68;
            this.txt_codigo_empleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_empleado_KeyPress);
            // 
            // txt_codigo_compra
            // 
            this.txt_codigo_compra.Location = new System.Drawing.Point(680, 302);
            this.txt_codigo_compra.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo_compra.Name = "txt_codigo_compra";
            this.txt_codigo_compra.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo_compra.TabIndex = 67;
            this.txt_codigo_compra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_compra_KeyPress);
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(680, 254);
            this.txt_estado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(187, 22);
            this.txt_estado.TabIndex = 66;
            this.txt_estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_estado_KeyPress);
            // 
            // txt_fecha
            // 
            this.txt_fecha.Location = new System.Drawing.Point(680, 207);
            this.txt_fecha.Margin = new System.Windows.Forms.Padding(4);
            this.txt_fecha.Name = "txt_fecha";
            this.txt_fecha.Size = new System.Drawing.Size(187, 22);
            this.txt_fecha.TabIndex = 65;
            // 
            // dgv_entrada_compra
            // 
            this.dgv_entrada_compra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_entrada_compra.Location = new System.Drawing.Point(407, 414);
            this.dgv_entrada_compra.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_entrada_compra.Name = "dgv_entrada_compra";
            this.dgv_entrada_compra.RowHeadersWidth = 51;
            this.dgv_entrada_compra.Size = new System.Drawing.Size(557, 185);
            this.dgv_entrada_compra.TabIndex = 64;
            // 
            // txt_codigo
            // 
            this.txt_codigo.Location = new System.Drawing.Point(680, 161);
            this.txt_codigo.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo.TabIndex = 63;
            this.txt_codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_KeyPress_1);
            // 
            // lb_codigo
            // 
            this.lb_codigo.AutoSize = true;
            this.lb_codigo.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo.ForeColor = System.Drawing.Color.White;
            this.lb_codigo.Location = new System.Drawing.Point(456, 160);
            this.lb_codigo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo.Name = "lb_codigo";
            this.lb_codigo.Size = new System.Drawing.Size(204, 23);
            this.lb_codigo.TabIndex = 62;
            this.lb_codigo.Text = "Código Entrada Compra";
            // 
            // Frm_entrada_compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green21;
            this.ClientSize = new System.Drawing.Size(1073, 626);
            this.Controls.Add(this.Lb_codigo_empleado);
            this.Controls.Add(this.Lb_codigo_compra);
            this.Controls.Add(this.Lb_estado);
            this.Controls.Add(this.lb_fecha);
            this.Controls.Add(this.txt_codigo_empleado);
            this.Controls.Add(this.txt_codigo_compra);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.txt_fecha);
            this.Controls.Add(this.dgv_entrada_compra);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.lb_codigo);
            this.Controls.Add(this.pnl_izquierda);
            this.Controls.Add(this.Pnl_arriba);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_entrada_compra";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Entrada Compra";
            this.Load += new System.EventHandler(this.Frm_entrada_compra_Load);
            this.pnl_izquierda.ResumeLayout(false);
            this.Pnl_arriba.ResumeLayout(false);
            this.Pnl_arriba.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_entrada_compra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnl_izquierda;
        private System.Windows.Forms.Panel Pnl_arriba;
        private System.Windows.Forms.Button Btn_crear;
        private System.Windows.Forms.Button Btn_volver;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Button Btn_modificar;
        private System.Windows.Forms.Button Btn_consultar;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Label lB_TITULO;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Lb_codigo_empleado;
        private System.Windows.Forms.Label Lb_codigo_compra;
        private System.Windows.Forms.Label Lb_estado;
        private System.Windows.Forms.Label lb_fecha;
        private System.Windows.Forms.TextBox txt_codigo_empleado;
        private System.Windows.Forms.TextBox txt_codigo_compra;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.TextBox txt_fecha;
        private System.Windows.Forms.DataGridView dgv_entrada_compra;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label lb_codigo;
    }
}