﻿namespace Vitagardenn_interfaz
{
    partial class frm_Menu_priincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Menu_priincipal));
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.Btn_menu_principal = new System.Windows.Forms.Button();
            this.Btn_menu_productos = new System.Windows.Forms.Button();
            this.Btn_telefonos = new System.Windows.Forms.Button();
            this.Btn_detalles = new System.Windows.Forms.Button();
            this.Btn_reportes = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(40, 28);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 1;
            this.Ptb_titulo.TabStop = false;
            // 
            // Btn_menu_principal
            // 
            this.Btn_menu_principal.BackColor = System.Drawing.Color.White;
            this.Btn_menu_principal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_menu_principal.Location = new System.Drawing.Point(40, 113);
            this.Btn_menu_principal.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_menu_principal.Name = "Btn_menu_principal";
            this.Btn_menu_principal.Size = new System.Drawing.Size(295, 103);
            this.Btn_menu_principal.TabIndex = 2;
            this.Btn_menu_principal.Text = "PRINCIPAL";
            this.Btn_menu_principal.UseVisualStyleBackColor = false;
            this.Btn_menu_principal.Click += new System.EventHandler(this.Btn_menu_principal_Click);
            // 
            // Btn_menu_productos
            // 
            this.Btn_menu_productos.BackColor = System.Drawing.Color.White;
            this.Btn_menu_productos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_menu_productos.Location = new System.Drawing.Point(40, 235);
            this.Btn_menu_productos.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_menu_productos.Name = "Btn_menu_productos";
            this.Btn_menu_productos.Size = new System.Drawing.Size(295, 103);
            this.Btn_menu_productos.TabIndex = 3;
            this.Btn_menu_productos.Text = "PRODUCTOS";
            this.Btn_menu_productos.UseVisualStyleBackColor = false;
            this.Btn_menu_productos.Click += new System.EventHandler(this.Btn_menu_productos_Click);
            // 
            // Btn_telefonos
            // 
            this.Btn_telefonos.BackColor = System.Drawing.Color.White;
            this.Btn_telefonos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_telefonos.Location = new System.Drawing.Point(40, 357);
            this.Btn_telefonos.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_telefonos.Name = "Btn_telefonos";
            this.Btn_telefonos.Size = new System.Drawing.Size(295, 103);
            this.Btn_telefonos.TabIndex = 4;
            this.Btn_telefonos.Text = "TELÉFONOS";
            this.Btn_telefonos.UseVisualStyleBackColor = false;
            this.Btn_telefonos.Click += new System.EventHandler(this.Btn_telefonos_Click);
            // 
            // Btn_detalles
            // 
            this.Btn_detalles.BackColor = System.Drawing.Color.White;
            this.Btn_detalles.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_detalles.Location = new System.Drawing.Point(40, 481);
            this.Btn_detalles.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_detalles.Name = "Btn_detalles";
            this.Btn_detalles.Size = new System.Drawing.Size(295, 103);
            this.Btn_detalles.TabIndex = 5;
            this.Btn_detalles.Text = "DETALLES";
            this.Btn_detalles.UseVisualStyleBackColor = false;
            this.Btn_detalles.Click += new System.EventHandler(this.Btn_detalles_Click);
            // 
            // Btn_reportes
            // 
            this.Btn_reportes.BackColor = System.Drawing.Color.White;
            this.Btn_reportes.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_reportes.Location = new System.Drawing.Point(40, 604);
            this.Btn_reportes.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_reportes.Name = "Btn_reportes";
            this.Btn_reportes.Size = new System.Drawing.Size(295, 103);
            this.Btn_reportes.TabIndex = 6;
            this.Btn_reportes.Text = "REPORTES";
            this.Btn_reportes.UseVisualStyleBackColor = false;
            this.Btn_reportes.Click += new System.EventHandler(this.Btn_reportes_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.BackColor = System.Drawing.Color.White;
            this.btn_volver.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.Location = new System.Drawing.Point(1045, 604);
            this.btn_volver.Margin = new System.Windows.Forms.Padding(4);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(295, 103);
            this.btn_volver.TabIndex = 7;
            this.btn_volver.Text = "VOLVER LOGIN";
            this.btn_volver.UseVisualStyleBackColor = false;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // frm_Menu_priincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.image;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1364, 758);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.Btn_reportes);
            this.Controls.Add(this.Btn_detalles);
            this.Controls.Add(this.Btn_telefonos);
            this.Controls.Add(this.Btn_menu_productos);
            this.Controls.Add(this.Btn_menu_principal);
            this.Controls.Add(this.Ptb_titulo);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_Menu_priincipal";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Menú ";
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_menu_principal;
        private System.Windows.Forms.Button Btn_menu_productos;
        private System.Windows.Forms.Button Btn_telefonos;
        private System.Windows.Forms.Button Btn_detalles;
        private System.Windows.Forms.Button Btn_reportes;
        private System.Windows.Forms.Button btn_volver;
    }
}