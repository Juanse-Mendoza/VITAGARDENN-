﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class frm_Menu_telefonos : Form
    {
        public frm_Menu_telefonos()
        {
            InitializeComponent();
        }

        private void Btn_telefono_empleado_Click(object sender, EventArgs e)
        {
            Frm_Tel_emplead emplead = new Frm_Tel_emplead();
            emplead.Show();
            this.Hide();
        }

        private void Btn_telefono_cliente_Click(object sender, EventArgs e)
        {
            Frm_Tel_cliente tel_Cliente = new Frm_Tel_cliente();
            tel_Cliente.Show();
            this.Hide();
        }

        private void Btn_telefono_proveedor_Click(object sender, EventArgs e)
        {
            Frm_Tel_proveedor proveedor = new Frm_Tel_proveedor();
            proveedor.Show();
            this.Hide();
        }

        private void Ptb_titulo_Click(object sender, EventArgs e)
        {
            frm_Menu_priincipal menu_Priincipal = new frm_Menu_priincipal();
            menu_Priincipal.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
