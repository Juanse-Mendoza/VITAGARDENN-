﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_Producto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Producto));
            this.dgv_producto = new System.Windows.Forms.DataGridView();
            this.txt_empleado = new System.Windows.Forms.TextBox();
            this.lb_codigo_empleado = new System.Windows.Forms.Label();
            this.txt_codigo_proveedor = new System.Windows.Forms.TextBox();
            this.lb_codigo_proveedor = new System.Windows.Forms.Label();
            this.txt_cantidad = new System.Windows.Forms.TextBox();
            this.txt_valor = new System.Windows.Forms.TextBox();
            this.lb_cantidad = new System.Windows.Forms.Label();
            this.lb_valor = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.lb_nombre = new System.Windows.Forms.Label();
            this.lb_codigo = new System.Windows.Forms.Label();
            this.pnl_izquierda = new System.Windows.Forms.Panel();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Btn_modificar = new System.Windows.Forms.Button();
            this.Btn_crear = new System.Windows.Forms.Button();
            this.Btn_volver = new System.Windows.Forms.Button();
            this.Btn_consultar = new System.Windows.Forms.Button();
            this.Pnl_arriba = new System.Windows.Forms.Panel();
            this.lB_TITULO = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.lb_estado = new System.Windows.Forms.Label();
            this.txt_estado = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).BeginInit();
            this.pnl_izquierda.SuspendLayout();
            this.Pnl_arriba.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_producto
            // 
            this.dgv_producto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_producto.Location = new System.Drawing.Point(395, 511);
            this.dgv_producto.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_producto.Name = "dgv_producto";
            this.dgv_producto.RowHeadersWidth = 51;
            this.dgv_producto.Size = new System.Drawing.Size(591, 185);
            this.dgv_producto.TabIndex = 37;
            // 
            // txt_empleado
            // 
            this.txt_empleado.Location = new System.Drawing.Point(660, 368);
            this.txt_empleado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_empleado.Name = "txt_empleado";
            this.txt_empleado.Size = new System.Drawing.Size(187, 22);
            this.txt_empleado.TabIndex = 36;
            this.txt_empleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_empleado_KeyPress);
            // 
            // lb_codigo_empleado
            // 
            this.lb_codigo_empleado.AutoSize = true;
            this.lb_codigo_empleado.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo_empleado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo_empleado.ForeColor = System.Drawing.Color.White;
            this.lb_codigo_empleado.Location = new System.Drawing.Point(489, 367);
            this.lb_codigo_empleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo_empleado.Name = "lb_codigo_empleado";
            this.lb_codigo_empleado.Size = new System.Drawing.Size(157, 23);
            this.lb_codigo_empleado.TabIndex = 35;
            this.lb_codigo_empleado.Text = "Código Empleado";
            // 
            // txt_codigo_proveedor
            // 
            this.txt_codigo_proveedor.Location = new System.Drawing.Point(660, 415);
            this.txt_codigo_proveedor.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo_proveedor.Name = "txt_codigo_proveedor";
            this.txt_codigo_proveedor.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo_proveedor.TabIndex = 34;
            this.txt_codigo_proveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_proveedor_KeyPress);
            // 
            // lb_codigo_proveedor
            // 
            this.lb_codigo_proveedor.AutoSize = true;
            this.lb_codigo_proveedor.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo_proveedor.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo_proveedor.ForeColor = System.Drawing.Color.White;
            this.lb_codigo_proveedor.Location = new System.Drawing.Point(485, 416);
            this.lb_codigo_proveedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo_proveedor.Name = "lb_codigo_proveedor";
            this.lb_codigo_proveedor.Size = new System.Drawing.Size(159, 23);
            this.lb_codigo_proveedor.TabIndex = 32;
            this.lb_codigo_proveedor.Text = "Código Proveedor";
            // 
            // txt_cantidad
            // 
            this.txt_cantidad.Location = new System.Drawing.Point(660, 321);
            this.txt_cantidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cantidad.Name = "txt_cantidad";
            this.txt_cantidad.Size = new System.Drawing.Size(187, 22);
            this.txt_cantidad.TabIndex = 30;
            this.txt_cantidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_cantidad_KeyPress);
            // 
            // txt_valor
            // 
            this.txt_valor.Location = new System.Drawing.Point(660, 274);
            this.txt_valor.Margin = new System.Windows.Forms.Padding(4);
            this.txt_valor.Name = "txt_valor";
            this.txt_valor.Size = new System.Drawing.Size(187, 22);
            this.txt_valor.TabIndex = 29;
            this.txt_valor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_valor_KeyPress);
            // 
            // lb_cantidad
            // 
            this.lb_cantidad.AutoSize = true;
            this.lb_cantidad.BackColor = System.Drawing.Color.Transparent;
            this.lb_cantidad.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cantidad.ForeColor = System.Drawing.Color.White;
            this.lb_cantidad.Location = new System.Drawing.Point(560, 322);
            this.lb_cantidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_cantidad.Name = "lb_cantidad";
            this.lb_cantidad.Size = new System.Drawing.Size(82, 23);
            this.lb_cantidad.TabIndex = 28;
            this.lb_cantidad.Text = "Cantidad";
            // 
            // lb_valor
            // 
            this.lb_valor.AutoSize = true;
            this.lb_valor.BackColor = System.Drawing.Color.Transparent;
            this.lb_valor.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_valor.ForeColor = System.Drawing.Color.White;
            this.lb_valor.Location = new System.Drawing.Point(591, 274);
            this.lb_valor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_valor.Name = "lb_valor";
            this.lb_valor.Size = new System.Drawing.Size(53, 23);
            this.lb_valor.TabIndex = 27;
            this.lb_valor.Text = "Valor";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(660, 226);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(187, 22);
            this.txt_nombre.TabIndex = 26;
            // 
            // txt_codigo
            // 
            this.txt_codigo.Location = new System.Drawing.Point(660, 181);
            this.txt_codigo.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo.TabIndex = 25;
            this.txt_codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_KeyPress);
            // 
            // lb_nombre
            // 
            this.lb_nombre.AutoSize = true;
            this.lb_nombre.BackColor = System.Drawing.Color.Transparent;
            this.lb_nombre.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nombre.ForeColor = System.Drawing.Color.White;
            this.lb_nombre.Location = new System.Drawing.Point(484, 226);
            this.lb_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_nombre.Name = "lb_nombre";
            this.lb_nombre.Size = new System.Drawing.Size(157, 23);
            this.lb_nombre.TabIndex = 24;
            this.lb_nombre.Text = "Nombre Producto";
            // 
            // lb_codigo
            // 
            this.lb_codigo.AutoSize = true;
            this.lb_codigo.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo.ForeColor = System.Drawing.Color.White;
            this.lb_codigo.Location = new System.Drawing.Point(493, 182);
            this.lb_codigo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo.Name = "lb_codigo";
            this.lb_codigo.Size = new System.Drawing.Size(149, 23);
            this.lb_codigo.TabIndex = 23;
            this.lb_codigo.Text = "Código Producto";
            // 
            // pnl_izquierda
            // 
            this.pnl_izquierda.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green1;
            this.pnl_izquierda.Controls.Add(this.Btn_eliminar);
            this.pnl_izquierda.Controls.Add(this.Btn_modificar);
            this.pnl_izquierda.Controls.Add(this.Btn_crear);
            this.pnl_izquierda.Controls.Add(this.Btn_volver);
            this.pnl_izquierda.Controls.Add(this.Btn_consultar);
            this.pnl_izquierda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_izquierda.Location = new System.Drawing.Point(0, 110);
            this.pnl_izquierda.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_izquierda.Name = "pnl_izquierda";
            this.pnl_izquierda.Size = new System.Drawing.Size(267, 640);
            this.pnl_izquierda.TabIndex = 22;
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_eliminar.Location = new System.Drawing.Point(32, 370);
            this.Btn_eliminar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(203, 54);
            this.Btn_eliminar.TabIndex = 83;
            this.Btn_eliminar.Text = "ELIMINAR";
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            this.Btn_eliminar.Click += new System.EventHandler(this.Btn_eliminar_Click);
            // 
            // Btn_modificar
            // 
            this.Btn_modificar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_modificar.Location = new System.Drawing.Point(32, 287);
            this.Btn_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_modificar.Name = "Btn_modificar";
            this.Btn_modificar.Size = new System.Drawing.Size(203, 54);
            this.Btn_modificar.TabIndex = 82;
            this.Btn_modificar.Text = "MODIFICAR";
            this.Btn_modificar.UseVisualStyleBackColor = true;
            this.Btn_modificar.Click += new System.EventHandler(this.Btn_modificar_Click);
            // 
            // Btn_crear
            // 
            this.Btn_crear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_crear.Location = new System.Drawing.Point(32, 122);
            this.Btn_crear.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_crear.Name = "Btn_crear";
            this.Btn_crear.Size = new System.Drawing.Size(203, 54);
            this.Btn_crear.TabIndex = 79;
            this.Btn_crear.Text = "CREAR";
            this.Btn_crear.UseVisualStyleBackColor = true;
            this.Btn_crear.Click += new System.EventHandler(this.Btn_crear_Click);
            // 
            // Btn_volver
            // 
            this.Btn_volver.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_volver.Location = new System.Drawing.Point(32, 455);
            this.Btn_volver.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_volver.Name = "Btn_volver";
            this.Btn_volver.Size = new System.Drawing.Size(203, 54);
            this.Btn_volver.TabIndex = 80;
            this.Btn_volver.Text = "VOLVER";
            this.Btn_volver.UseVisualStyleBackColor = true;
            this.Btn_volver.Click += new System.EventHandler(this.Btn_volver_Click);
            // 
            // Btn_consultar
            // 
            this.Btn_consultar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_consultar.Location = new System.Drawing.Point(32, 204);
            this.Btn_consultar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_consultar.Name = "Btn_consultar";
            this.Btn_consultar.Size = new System.Drawing.Size(203, 54);
            this.Btn_consultar.TabIndex = 81;
            this.Btn_consultar.Text = "CONSULTAR";
            this.Btn_consultar.UseVisualStyleBackColor = true;
            this.Btn_consultar.Click += new System.EventHandler(this.Btn_consultar_Click);
            // 
            // Pnl_arriba
            // 
            this.Pnl_arriba.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.green3;
            this.Pnl_arriba.Controls.Add(this.lB_TITULO);
            this.Pnl_arriba.Controls.Add(this.Ptb_titulo);
            this.Pnl_arriba.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_arriba.Location = new System.Drawing.Point(0, 0);
            this.Pnl_arriba.Margin = new System.Windows.Forms.Padding(4);
            this.Pnl_arriba.Name = "Pnl_arriba";
            this.Pnl_arriba.Size = new System.Drawing.Size(1100, 110);
            this.Pnl_arriba.TabIndex = 21;
            // 
            // lB_TITULO
            // 
            this.lB_TITULO.AutoSize = true;
            this.lB_TITULO.BackColor = System.Drawing.Color.Transparent;
            this.lB_TITULO.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lB_TITULO.ForeColor = System.Drawing.Color.White;
            this.lB_TITULO.Location = new System.Drawing.Point(55, 55);
            this.lB_TITULO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lB_TITULO.Name = "lB_TITULO";
            this.lB_TITULO.Size = new System.Drawing.Size(163, 33);
            this.lB_TITULO.TabIndex = 6;
            this.lB_TITULO.Text = "PRODUCTO";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(32, 15);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.BackColor = System.Drawing.Color.Transparent;
            this.lb_estado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_estado.ForeColor = System.Drawing.Color.White;
            this.lb_estado.Location = new System.Drawing.Point(582, 467);
            this.lb_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(64, 23);
            this.lb_estado.TabIndex = 38;
            this.lb_estado.Text = "Estado";
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(660, 467);
            this.txt_estado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(187, 22);
            this.txt_estado.TabIndex = 39;
            this.txt_estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_estado_KeyPress);
            // 
            // Frm_Producto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green2;
            this.ClientSize = new System.Drawing.Size(1100, 750);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.lb_estado);
            this.Controls.Add(this.dgv_producto);
            this.Controls.Add(this.txt_empleado);
            this.Controls.Add(this.lb_codigo_empleado);
            this.Controls.Add(this.txt_codigo_proveedor);
            this.Controls.Add(this.lb_codigo_proveedor);
            this.Controls.Add(this.txt_cantidad);
            this.Controls.Add(this.txt_valor);
            this.Controls.Add(this.lb_cantidad);
            this.Controls.Add(this.lb_valor);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.lb_nombre);
            this.Controls.Add(this.lb_codigo);
            this.Controls.Add(this.pnl_izquierda);
            this.Controls.Add(this.Pnl_arriba);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Producto";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Producto";
            this.Load += new System.EventHandler(this.Frm_Producto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).EndInit();
            this.pnl_izquierda.ResumeLayout(false);
            this.Pnl_arriba.ResumeLayout(false);
            this.Pnl_arriba.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_producto;
        private System.Windows.Forms.TextBox txt_empleado;
        private System.Windows.Forms.Label lb_codigo_empleado;
        private System.Windows.Forms.TextBox txt_codigo_proveedor;
        private System.Windows.Forms.Label lb_codigo_proveedor;
        private System.Windows.Forms.TextBox txt_cantidad;
        private System.Windows.Forms.TextBox txt_valor;
        private System.Windows.Forms.Label lb_cantidad;
        private System.Windows.Forms.Label lb_valor;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label lb_nombre;
        private System.Windows.Forms.Label lb_codigo;
        private System.Windows.Forms.Panel pnl_izquierda;
        private System.Windows.Forms.Panel Pnl_arriba;
        private System.Windows.Forms.Label lB_TITULO;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Button Btn_modificar;
        private System.Windows.Forms.Button Btn_volver;
        private System.Windows.Forms.Button Btn_consultar;
        private System.Windows.Forms.Button Btn_crear;
        private System.Windows.Forms.Label lb_estado;
        private System.Windows.Forms.TextBox txt_estado;
    }
}