﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Usuario : Form
    {
        LOGICA.Clase_usuario obj_Usuario = new Clase_usuario();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Usuario()
        {
            InitializeComponent();
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Usuario.nombre_usuarioM = txt_nombre.Text;
            obj_Usuario.contraseña_usuarioM = txt_contraseña.Text;
            obj_Usuario.id_empleado_fk_usuarioM = long.Parse(txt_codigo_empleado.Text);
            obj_Usuario.insertar_usuario();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Usuario.Consultageneral_usuario(ref dgv_usuario);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_nombre.Text == "")
            {
                MessageBox.Show("Digite el nombre del usuario que desea actualizar");
            }
            else if (txt_nombre.Text != "")
            {
                obj_Usuario.nombre_usuarioM = txt_nombre.Text;
                obj_Usuario.contraseña_usuarioM = txt_contraseña.Text;
                obj_Usuario.id_empleado_fk_usuarioM = long.Parse(txt_codigo_empleado.Text);
                obj_Usuario.actualizar_usuario();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_nombre.Text = "";
            txt_contraseña.Text = "";
            txt_codigo_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_nombre.Text == "")
            {
                MessageBox.Show("Digite el nombre del usuario que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Usuario.nombre_usuarioM =  txt_nombre.Text;
                obj_Usuario.eliminar_usuario();
            }
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_codigo_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
