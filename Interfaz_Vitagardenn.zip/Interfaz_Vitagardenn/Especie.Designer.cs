﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_Especie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Especie));
            this.dgv_especie = new System.Windows.Forms.DataGridView();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.lb_nombre = new System.Windows.Forms.Label();
            this.lb_codigo = new System.Windows.Forms.Label();
            this.pnl_izquierda = new System.Windows.Forms.Panel();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Btn_modificar = new System.Windows.Forms.Button();
            this.Btn_volver = new System.Windows.Forms.Button();
            this.Btn_consultar = new System.Windows.Forms.Button();
            this.Btn_crear = new System.Windows.Forms.Button();
            this.Pnl_arriba = new System.Windows.Forms.Panel();
            this.lB_TITULO = new System.Windows.Forms.Label();
            this.Ptb_titulo = new System.Windows.Forms.PictureBox();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.lb_estado = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_especie)).BeginInit();
            this.pnl_izquierda.SuspendLayout();
            this.Pnl_arriba.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_especie
            // 
            this.dgv_especie.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_especie.Location = new System.Drawing.Point(395, 329);
            this.dgv_especie.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_especie.Name = "dgv_especie";
            this.dgv_especie.RowHeadersWidth = 51;
            this.dgv_especie.Size = new System.Drawing.Size(457, 185);
            this.dgv_especie.TabIndex = 37;
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(608, 230);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(187, 22);
            this.txt_nombre.TabIndex = 26;
            this.txt_nombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_nombre_KeyPress);
            // 
            // txt_codigo
            // 
            this.txt_codigo.Location = new System.Drawing.Point(610, 183);
            this.txt_codigo.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(187, 22);
            this.txt_codigo.TabIndex = 25;
            this.txt_codigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_codigo_KeyPress);
            // 
            // lb_nombre
            // 
            this.lb_nombre.AutoSize = true;
            this.lb_nombre.BackColor = System.Drawing.Color.Transparent;
            this.lb_nombre.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nombre.ForeColor = System.Drawing.Color.White;
            this.lb_nombre.Location = new System.Drawing.Point(455, 229);
            this.lb_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_nombre.Name = "lb_nombre";
            this.lb_nombre.Size = new System.Drawing.Size(145, 23);
            this.lb_nombre.TabIndex = 24;
            this.lb_nombre.Text = "Nombre Especie";
            // 
            // lb_codigo
            // 
            this.lb_codigo.AutoSize = true;
            this.lb_codigo.BackColor = System.Drawing.Color.Transparent;
            this.lb_codigo.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_codigo.ForeColor = System.Drawing.Color.White;
            this.lb_codigo.Location = new System.Drawing.Point(465, 182);
            this.lb_codigo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_codigo.Name = "lb_codigo";
            this.lb_codigo.Size = new System.Drawing.Size(137, 23);
            this.lb_codigo.TabIndex = 23;
            this.lb_codigo.Text = "Código Especie";
            // 
            // pnl_izquierda
            // 
            this.pnl_izquierda.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green1;
            this.pnl_izquierda.Controls.Add(this.Btn_eliminar);
            this.pnl_izquierda.Controls.Add(this.Btn_modificar);
            this.pnl_izquierda.Controls.Add(this.Btn_volver);
            this.pnl_izquierda.Controls.Add(this.Btn_consultar);
            this.pnl_izquierda.Controls.Add(this.Btn_crear);
            this.pnl_izquierda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_izquierda.Location = new System.Drawing.Point(0, 110);
            this.pnl_izquierda.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_izquierda.Name = "pnl_izquierda";
            this.pnl_izquierda.Size = new System.Drawing.Size(267, 489);
            this.pnl_izquierda.TabIndex = 22;
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_eliminar.Location = new System.Drawing.Point(35, 303);
            this.Btn_eliminar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(203, 54);
            this.Btn_eliminar.TabIndex = 78;
            this.Btn_eliminar.Text = "ELIMINAR";
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            this.Btn_eliminar.Click += new System.EventHandler(this.Btn_eliminar_Click);
            // 
            // Btn_modificar
            // 
            this.Btn_modificar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_modificar.Location = new System.Drawing.Point(35, 219);
            this.Btn_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_modificar.Name = "Btn_modificar";
            this.Btn_modificar.Size = new System.Drawing.Size(203, 54);
            this.Btn_modificar.TabIndex = 77;
            this.Btn_modificar.Text = "MODIFICAR";
            this.Btn_modificar.UseVisualStyleBackColor = true;
            this.Btn_modificar.Click += new System.EventHandler(this.Btn_modificar_Click);
            // 
            // Btn_volver
            // 
            this.Btn_volver.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_volver.Location = new System.Drawing.Point(35, 388);
            this.Btn_volver.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_volver.Name = "Btn_volver";
            this.Btn_volver.Size = new System.Drawing.Size(203, 54);
            this.Btn_volver.TabIndex = 75;
            this.Btn_volver.Text = "VOLVER";
            this.Btn_volver.UseVisualStyleBackColor = true;
            this.Btn_volver.Click += new System.EventHandler(this.Btn_volver_Click);
            // 
            // Btn_consultar
            // 
            this.Btn_consultar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_consultar.Location = new System.Drawing.Point(35, 137);
            this.Btn_consultar.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_consultar.Name = "Btn_consultar";
            this.Btn_consultar.Size = new System.Drawing.Size(203, 54);
            this.Btn_consultar.TabIndex = 76;
            this.Btn_consultar.Text = "CONSULTAR";
            this.Btn_consultar.UseVisualStyleBackColor = true;
            this.Btn_consultar.Click += new System.EventHandler(this.Btn_consultar_Click);
            // 
            // Btn_crear
            // 
            this.Btn_crear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_crear.Location = new System.Drawing.Point(35, 54);
            this.Btn_crear.Margin = new System.Windows.Forms.Padding(4);
            this.Btn_crear.Name = "Btn_crear";
            this.Btn_crear.Size = new System.Drawing.Size(203, 54);
            this.Btn_crear.TabIndex = 74;
            this.Btn_crear.Text = "CREAR";
            this.Btn_crear.UseVisualStyleBackColor = true;
            this.Btn_crear.Click += new System.EventHandler(this.Btn_crear_Click);
            // 
            // Pnl_arriba
            // 
            this.Pnl_arriba.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.green3;
            this.Pnl_arriba.Controls.Add(this.lB_TITULO);
            this.Pnl_arriba.Controls.Add(this.Ptb_titulo);
            this.Pnl_arriba.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_arriba.Location = new System.Drawing.Point(0, 0);
            this.Pnl_arriba.Margin = new System.Windows.Forms.Padding(4);
            this.Pnl_arriba.Name = "Pnl_arriba";
            this.Pnl_arriba.Size = new System.Drawing.Size(988, 110);
            this.Pnl_arriba.TabIndex = 21;
            // 
            // lB_TITULO
            // 
            this.lB_TITULO.AutoSize = true;
            this.lB_TITULO.BackColor = System.Drawing.Color.Transparent;
            this.lB_TITULO.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lB_TITULO.ForeColor = System.Drawing.Color.White;
            this.lB_TITULO.Location = new System.Drawing.Point(57, 55);
            this.lB_TITULO.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lB_TITULO.Name = "lB_TITULO";
            this.lB_TITULO.Size = new System.Drawing.Size(114, 33);
            this.lB_TITULO.TabIndex = 6;
            this.lB_TITULO.Text = "ESPECIE";
            // 
            // Ptb_titulo
            // 
            this.Ptb_titulo.BackColor = System.Drawing.Color.Transparent;
            this.Ptb_titulo.Image = global::Vitagardenn_interfaz.Properties.Resources.LOGO_INICIO;
            this.Ptb_titulo.Location = new System.Drawing.Point(35, 15);
            this.Ptb_titulo.Margin = new System.Windows.Forms.Padding(4);
            this.Ptb_titulo.Name = "Ptb_titulo";
            this.Ptb_titulo.Size = new System.Drawing.Size(700, 37);
            this.Ptb_titulo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Ptb_titulo.TabIndex = 5;
            this.Ptb_titulo.TabStop = false;
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(610, 279);
            this.txt_estado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(187, 22);
            this.txt_estado.TabIndex = 38;
            this.txt_estado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_estado_KeyPress);
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.BackColor = System.Drawing.Color.Transparent;
            this.lb_estado.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_estado.ForeColor = System.Drawing.Color.White;
            this.lb_estado.Location = new System.Drawing.Point(455, 278);
            this.lb_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(137, 23);
            this.lb_estado.TabIndex = 39;
            this.lb_estado.Text = "Nombre Estado";
            // 
            // Frm_Especie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Green2;
            this.ClientSize = new System.Drawing.Size(988, 599);
            this.Controls.Add(this.lb_estado);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.dgv_especie);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.lb_nombre);
            this.Controls.Add(this.lb_codigo);
            this.Controls.Add(this.pnl_izquierda);
            this.Controls.Add(this.Pnl_arriba);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Especie";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Especie";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_especie)).EndInit();
            this.pnl_izquierda.ResumeLayout(false);
            this.Pnl_arriba.ResumeLayout(false);
            this.Pnl_arriba.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ptb_titulo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_especie;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label lb_nombre;
        private System.Windows.Forms.Label lb_codigo;
        private System.Windows.Forms.Panel pnl_izquierda;
        private System.Windows.Forms.Panel Pnl_arriba;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Button Btn_volver;
        private System.Windows.Forms.Button Btn_modificar;
        private System.Windows.Forms.Button Btn_crear;
        private System.Windows.Forms.Button Btn_consultar;
        private System.Windows.Forms.Label lB_TITULO;
        private System.Windows.Forms.PictureBox Ptb_titulo;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.Label lb_estado;
    }
}