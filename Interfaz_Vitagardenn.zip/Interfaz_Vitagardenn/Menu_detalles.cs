﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class frm_Menu_detalles : Form
    {
        public frm_Menu_detalles()
        {
            InitializeComponent();
        }

        private void Menu_detalles_Load(object sender, EventArgs e)
        {

        }

        private void Btn_d_venta_planta_Click(object sender, EventArgs e)
        {
            Frm_Det_venta_planta det_Venta_Planta = new Frm_Det_venta_planta();
            det_Venta_Planta.Show();
            this.Hide();
        }

        private void Btn_d_venta_producto_Click(object sender, EventArgs e)
        {
            Frm_Det_venta_producto det_Venta_Producto = new Frm_Det_venta_producto();
            det_Venta_Producto.Show();
            this.Hide();
        }

        private void Btn_d_entrada_compra_producto_Click(object sender, EventArgs e)
        {
            Frm_Det_entrada_producto entrada_Producto = new Frm_Det_entrada_producto();
            entrada_Producto.Show();
            this.Hide();
        }

        private void Btn_d_compra_producto_Click(object sender, EventArgs e)
        {
            frm_Det_compra_producto compra_Producto = new frm_Det_compra_producto();
            compra_Producto.Show();
            this.Hide();
        }

        private void Btn_d_salida_inventario_producto_Click(object sender, EventArgs e)
        {
            frm_Det_salida_inventario_producto salida_Inventario_Producto = new frm_Det_salida_inventario_producto();
            salida_Inventario_Producto.Show();
            this.Hide();
        }

        private void Btn_d_salida_planta_Click(object sender, EventArgs e)
        {
            frm_Det_salida_planta salida_Planta = new frm_Det_salida_planta();
            salida_Planta.Show();
            this.Hide();
        }

        private void Ptb_titulo_Click(object sender, EventArgs e)
        {
            frm_Menu_priincipal priincipal = new frm_Menu_priincipal();
            priincipal.Show();
            this.Hide();
        }
    }
}
