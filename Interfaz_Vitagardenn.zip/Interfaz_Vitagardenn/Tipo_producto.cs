﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Tipo_producto : Form
    {
        LOGICA.Clase_tipo_producto obj_Tipo_producto = new Clase_tipo_producto();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Tipo_producto()
        {
            InitializeComponent();
        }

        private void lb_nombre_Click(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void lb_consulta_Click(object sender, EventArgs e)
        {

        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Tipo_producto.id_tipo_productoM = long.Parse(txt_codigo.Text);
            obj_Tipo_producto.nombre_tipo_productoM = txt_nombre.Text;
            obj_Tipo_producto.estado_tipo_productoM = txt_estado.Text;
            obj_Tipo_producto.id_producto_fk_tipo_productoM = long.Parse(txt_codigo_producto.Text);
            obj_Tipo_producto.insertar_tipo_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Tipo_producto.Consultageneral_tipo_producto(ref dgv_tipo_producto);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos productos = new Frm_Menu_productos();
            productos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del tipo de producto que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Tipo_producto.id_tipo_productoM = long.Parse(txt_codigo.Text);
                obj_Tipo_producto.nombre_tipo_productoM = txt_nombre.Text;
                obj_Tipo_producto.estado_tipo_productoM = txt_estado.Text;
                obj_Tipo_producto.id_producto_fk_tipo_productoM = long.Parse(txt_codigo_producto.Text);
                obj_Tipo_producto.actualizar_tipo_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_estado.Text = "";
            txt_codigo_producto.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del tipo de producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Tipo_producto.id_tipo_productoM = long.Parse(txt_codigo.Text);
                obj_Tipo_producto.eliminar_tipo_producto();
            }
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_codigo_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
