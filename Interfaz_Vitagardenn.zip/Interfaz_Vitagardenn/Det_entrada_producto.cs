﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Det_entrada_producto : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_detalle_entrada_producto obj_Entrada_producto = new Clase_detalle_entrada_producto();
        public Frm_Det_entrada_producto()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {

        }

        private void txt_cantidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_entrada_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cod_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {

        }

        private void txt_cantidad_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_valor_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_entrada_producto_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cod_producto_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Entrada_producto.cantidad_entrada_productoM = int.Parse(txt_cantidad.Text);
            obj_Entrada_producto.valor_entrada_productoM = (float)double.Parse(txt_valor.Text);
            obj_Entrada_producto.id_producto_fk_entrada_productoM = long.Parse(txt_cod_producto.Text);
            obj_Entrada_producto.id_venta_producto_fk_entrada_productoM = long.Parse(txt_codigo_venta_producto.Text);
            obj_Entrada_producto.insertar_entrada_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Entrada_producto.Consultageneral_entrada_producto(ref dgv_entrada_producto);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles frm_Menu_Detalles = new frm_Menu_detalles();
            frm_Menu_Detalles.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_cod_producto.Text == "")
            {
                MessageBox.Show("Digite el codigo de la entrada del producto que desea actualizar");
            }
            else if (txt_cod_producto.Text != "")
            {
                obj_Entrada_producto.cantidad_entrada_productoM = int.Parse(txt_cantidad.Text);
                obj_Entrada_producto.valor_entrada_productoM = (float)double.Parse(txt_valor.Text);
                obj_Entrada_producto.id_producto_fk_entrada_productoM = long.Parse(txt_cod_producto.Text);
                obj_Entrada_producto.id_venta_producto_fk_entrada_productoM = long.Parse(txt_codigo_venta_producto.Text);
                obj_Entrada_producto.actualizar_entrada_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_cantidad.Text = "";
            txt_valor.Text = "";
            txt_cod_producto.Text = "";
            txt_codigo_venta_producto.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_cod_producto.Text == "")
            {
                MessageBox.Show("Digite el codigo de la entrada del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Entrada_producto.id_producto_fk_entrada_productoM = long.Parse(txt_cod_producto.Text);
                obj_Entrada_producto.eliminar_entrada_producto();
            }
        }
    }
}
