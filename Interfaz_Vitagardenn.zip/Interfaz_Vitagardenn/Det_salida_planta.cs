﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class frm_Det_salida_planta : Form
    {

        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_detalle_salida_planta obj_salida_planta = new Clase_detalle_salida_planta();
        public frm_Det_salida_planta()
        {
            InitializeComponent();
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles detalles = new frm_Menu_detalles();
            detalles.Show();
            this.Hide();
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_salida_planta.observacionesM = txt_observaciones.Text;
            obj_salida_planta.cantidadM = int.Parse(txt_cantidad.Text);
            obj_salida_planta.id_planta_fk_salida_plantaM = long.Parse(txt_codigo_planta.Text);
            obj_salida_planta.id_salida_inventario_fk_salida_plantaM = long.Parse(txt_codigo_Salida_Inventario.Text);
            obj_salida_planta.insertar_salida_planta();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_salida_planta.Consultageneral_salida_planta(ref dgv_Det_salida_inventario);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_planta.Text == "")
            {
                MessageBox.Show("Digite el codigo de la planta que desea actualizar");
            }
            else if (txt_codigo_planta.Text != "")
            {
                obj_salida_planta.observacionesM = txt_observaciones.Text;
                obj_salida_planta.cantidadM = int.Parse(txt_cantidad.Text);
                obj_salida_planta.id_planta_fk_salida_plantaM = long.Parse(txt_codigo_planta.Text);
                obj_salida_planta.id_salida_inventario_fk_salida_plantaM = long.Parse(txt_codigo_Salida_Inventario.Text);
                obj_salida_planta.actualizar_salida_planta();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_observaciones.Text = "";
            txt_cantidad.Text = "";
            txt_codigo_planta.Text = "";
            txt_codigo_Salida_Inventario.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo_planta.Text == "")
            {
                MessageBox.Show("Digite el codigo de la planta que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_salida_planta.id_planta_fk_salida_plantaM = long.Parse(txt_codigo_planta.Text);
                obj_salida_planta.eliminar_salida_planta();
            }
        }

        private void txt_codigo_planta_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_Salida_Inventario_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
