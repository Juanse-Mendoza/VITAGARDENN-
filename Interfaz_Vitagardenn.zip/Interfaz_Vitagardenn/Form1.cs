﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Inicio : Form
    {
        public Frm_Inicio()
        {
            InitializeComponent();
        }

        private void lb_iniciar_Click(object sender, EventArgs e)
        {
            Frm_login lo = new Frm_login();
            lo.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Frm_login lo = new Frm_login();
            lo.Show();
            this.Hide();
        }
    }
}
