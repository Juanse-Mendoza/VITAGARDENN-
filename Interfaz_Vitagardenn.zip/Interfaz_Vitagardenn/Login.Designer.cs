﻿
namespace Vitagardenn_interfaz
{
    partial class Frm_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_login));
            this.pnl_inicio_sesion = new System.Windows.Forms.Panel();
            this.txt_val_contraseña = new System.Windows.Forms.TextBox();
            this.txt_val_usuario = new System.Windows.Forms.TextBox();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.lb_contraseña = new System.Windows.Forms.Label();
            this.lb_atras = new System.Windows.Forms.Label();
            this.lb_iniciar = new System.Windows.Forms.Label();
            this.lb_usuario = new System.Windows.Forms.Label();
            this.pnl_inicio_sesion.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_inicio_sesion
            // 
            this.pnl_inicio_sesion.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.LOGIN1_2;
            this.pnl_inicio_sesion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnl_inicio_sesion.Controls.Add(this.txt_val_contraseña);
            this.pnl_inicio_sesion.Controls.Add(this.txt_val_usuario);
            this.pnl_inicio_sesion.Controls.Add(this.txt_contraseña);
            this.pnl_inicio_sesion.Controls.Add(this.txt_usuario);
            this.pnl_inicio_sesion.Controls.Add(this.lb_contraseña);
            this.pnl_inicio_sesion.Controls.Add(this.lb_atras);
            this.pnl_inicio_sesion.Controls.Add(this.lb_iniciar);
            this.pnl_inicio_sesion.Controls.Add(this.lb_usuario);
            this.pnl_inicio_sesion.Location = new System.Drawing.Point(65, 68);
            this.pnl_inicio_sesion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pnl_inicio_sesion.Name = "pnl_inicio_sesion";
            this.pnl_inicio_sesion.Size = new System.Drawing.Size(417, 588);
            this.pnl_inicio_sesion.TabIndex = 0;
            // 
            // txt_val_contraseña
            // 
            this.txt_val_contraseña.Location = new System.Drawing.Point(155, 364);
            this.txt_val_contraseña.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_val_contraseña.Name = "txt_val_contraseña";
            this.txt_val_contraseña.Size = new System.Drawing.Size(187, 22);
            this.txt_val_contraseña.TabIndex = 7;
            // 
            // txt_val_usuario
            // 
            this.txt_val_usuario.Location = new System.Drawing.Point(155, 287);
            this.txt_val_usuario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_val_usuario.Name = "txt_val_usuario";
            this.txt_val_usuario.Size = new System.Drawing.Size(187, 22);
            this.txt_val_usuario.TabIndex = 6;
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Location = new System.Drawing.Point(155, 332);
            this.txt_contraseña.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.Size = new System.Drawing.Size(187, 22);
            this.txt_contraseña.TabIndex = 5;
            // 
            // txt_usuario
            // 
            this.txt_usuario.Location = new System.Drawing.Point(155, 255);
            this.txt_usuario.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(187, 22);
            this.txt_usuario.TabIndex = 4;
            this.txt_usuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_usuario_KeyPress);
            // 
            // lb_contraseña
            // 
            this.lb_contraseña.AutoSize = true;
            this.lb_contraseña.BackColor = System.Drawing.Color.Transparent;
            this.lb_contraseña.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_contraseña.ForeColor = System.Drawing.Color.White;
            this.lb_contraseña.Location = new System.Drawing.Point(4, 331);
            this.lb_contraseña.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_contraseña.Name = "lb_contraseña";
            this.lb_contraseña.Size = new System.Drawing.Size(137, 23);
            this.lb_contraseña.TabIndex = 3;
            this.lb_contraseña.Text = "CONSTRASEÑA";
            // 
            // lb_atras
            // 
            this.lb_atras.AutoSize = true;
            this.lb_atras.BackColor = System.Drawing.Color.Transparent;
            this.lb_atras.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_atras.ForeColor = System.Drawing.Color.White;
            this.lb_atras.Location = new System.Drawing.Point(164, 514);
            this.lb_atras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_atras.Name = "lb_atras";
            this.lb_atras.Size = new System.Drawing.Size(76, 27);
            this.lb_atras.TabIndex = 2;
            this.lb_atras.Text = "ATRÁS";
            this.lb_atras.Click += new System.EventHandler(this.lb_atras_Click);
            // 
            // lb_iniciar
            // 
            this.lb_iniciar.AutoSize = true;
            this.lb_iniciar.BackColor = System.Drawing.Color.Transparent;
            this.lb_iniciar.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_iniciar.ForeColor = System.Drawing.Color.White;
            this.lb_iniciar.Location = new System.Drawing.Point(121, 443);
            this.lb_iniciar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_iniciar.Name = "lb_iniciar";
            this.lb_iniciar.Size = new System.Drawing.Size(165, 27);
            this.lb_iniciar.TabIndex = 1;
            this.lb_iniciar.Text = "INICIAR SESIÓN";
            this.lb_iniciar.Click += new System.EventHandler(this.lb_iniciar_Click);
            // 
            // lb_usuario
            // 
            this.lb_usuario.AutoSize = true;
            this.lb_usuario.BackColor = System.Drawing.Color.Transparent;
            this.lb_usuario.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_usuario.ForeColor = System.Drawing.Color.White;
            this.lb_usuario.Location = new System.Drawing.Point(55, 256);
            this.lb_usuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_usuario.Name = "lb_usuario";
            this.lb_usuario.Size = new System.Drawing.Size(88, 23);
            this.lb_usuario.TabIndex = 0;
            this.lb_usuario.Text = "USUARIO";
            // 
            // Frm_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Vitagardenn_interfaz.Properties.Resources.Botanical_Background_Photos_and_Premium_High_Res_Pictures;
            this.ClientSize = new System.Drawing.Size(541, 734);
            this.Controls.Add(this.pnl_inicio_sesion);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frm_login";
            this.Text = "V  I  T  A  G  A  R  D  E  N  N  |  Inicio de Sesión";
            this.Load += new System.EventHandler(this.Frm_login_Load);
            this.pnl_inicio_sesion.ResumeLayout(false);
            this.pnl_inicio_sesion.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_inicio_sesion;
        private System.Windows.Forms.Label lb_usuario;
        private System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.Label lb_contraseña;
        private System.Windows.Forms.Label lb_atras;
        private System.Windows.Forms.Label lb_iniciar;
        private System.Windows.Forms.TextBox txt_val_contraseña;
        private System.Windows.Forms.TextBox txt_val_usuario;
    }
}