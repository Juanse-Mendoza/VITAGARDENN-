﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Tel_cliente : Form
    {
        LOGICA.Clase_telefono_cliente obj_Telefono_cliente = new Clase_telefono_cliente();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Tel_cliente()
        {
            InitializeComponent();
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Telefono_cliente.id_telefono_clienteM = long.Parse(txt_codigo.Text);
            obj_Telefono_cliente.numero_telefono_clienteM = int.Parse(txt_numero.Text);
            obj_Telefono_cliente.id_cliente_fk_telefonoM = long.Parse(txt_codigo_cliente.Text);
            obj_Telefono_cliente.insertar_telefono_cliente();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Telefono_cliente.Consultageneral_Tel_cliente(ref dgv_tel_cliente);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_telefonos telefonos = new frm_Menu_telefonos();
            telefonos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono del cliente que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Telefono_cliente.id_telefono_clienteM = long.Parse(txt_codigo.Text);
                obj_Telefono_cliente.numero_telefono_clienteM = int.Parse(txt_numero.Text);
                obj_Telefono_cliente.id_cliente_fk_telefonoM = long.Parse(txt_codigo_cliente.Text);
                obj_Telefono_cliente.actualizar_telefono_cliente();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_numero.Text = "";
            txt_codigo_cliente.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono del cliente que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Telefono_cliente.id_telefono_clienteM = long.Parse(txt_codigo.Text);
                obj_Telefono_cliente.eliminar_telefono_cliente();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_numero_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_cliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
