﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Empleado : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_empleado obj_Empleado = new Clase_empleado();
        public Frm_Empleado()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_salario_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void ptb_crear_Click_1(object sender, EventArgs e)
        {

        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            obj_Empleado.Consultageneral_empleado(ref dgv_empleado);
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Empleado.id_empleadoM = long.Parse(txt_codigo.Text);
            obj_Empleado.nombre_empleadoM = txt_nombre.Text;
            obj_Empleado.emailM = txt_email.Text;
            obj_Empleado.salarioM = (float)double.Parse(txt_salario.Text);
            obj_Empleado.estadoM = txt_estado.Text;
            obj_Empleado.insertar_empleado();
        }

        private void lb_consulta_Click(object sender, EventArgs e)
        {

        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Empleado.Consultageneral_empleado(ref dgv_empleado);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal prin = new Frm_Menu_mod_principal();
            prin.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del empleado que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Empleado.id_empleadoM = long.Parse(txt_codigo.Text);
                obj_Empleado.nombre_empleadoM = txt_nombre.Text;
                obj_Empleado.emailM = txt_email.Text;
                obj_Empleado.salarioM = (float)double.Parse(txt_salario.Text);
                obj_Empleado.estadoM = txt_estado.Text;
                obj_Empleado.actualizar_empleado();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_email.Text = "";
            txt_salario.Text = "";
            txt_estado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del empleado que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Empleado.id_empleadoM = long.Parse(txt_codigo.Text);
                obj_Empleado.eliminar_empleado();
            }
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }
    }
}
