﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Planta : Form
    {
        LOGICA.Clase_planta obj_Planta = new Clase_planta();
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Planta()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {

        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Planta.id_plantaM = long.Parse(txt_codigo.Text);
            obj_Planta.nombre_plantaM = txt_nombre.Text;
            obj_Planta.valor_plantaM = float.Parse(txt_valor.Text);
            obj_Planta.cantidad_plantaM = int.Parse(txt_cantidad.Text);
            obj_Planta.estado_plantaM = txt_estado.Text;
            obj_Planta.id_especie_fk_plantaM = long.Parse(txt_especie.Text);
            obj_Planta.id_empleado_fk_plantaM = long.Parse(txt_empleado.Text);
            obj_Planta.insertar_planta();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Planta.Consultageneral_planta(ref dgv_planta);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos productos = new Frm_Menu_productos();
            productos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la planta que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Planta.id_plantaM = long.Parse(txt_codigo.Text);
                obj_Planta.nombre_plantaM = txt_nombre.Text;
                obj_Planta.valor_plantaM = float.Parse(txt_valor.Text);
                obj_Planta.cantidad_plantaM = int.Parse(txt_cantidad.Text);
                obj_Planta.estado_plantaM = txt_estado.Text;
                obj_Planta.id_especie_fk_plantaM = long.Parse(txt_especie.Text);
                obj_Planta.id_empleado_fk_plantaM = long.Parse(txt_empleado.Text);
                obj_Planta.actualizar_planta();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_nombre.Text = "";
            txt_valor.Text = "";
            txt_cantidad.Text = "";
            txt_estado.Text = "";
            txt_especie.Text = "";
            txt_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo de la planta que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Planta.id_plantaM = long.Parse(txt_codigo.Text);
                obj_Planta.eliminar_planta();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_nombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_valor_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_estado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }

        private void txt_especie_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
