﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class Frm_Tel_emplead : Form
    {
        LOGICA.Clase_telefono_empleado obj_Telefono_empleado = new Clase_telefono_empleado();
        VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        public Frm_Tel_emplead()
        {
            InitializeComponent();
        }

        private void lb_volver_Click(object sender, EventArgs e)
        {
        }

        private void ptb_consultar_Click(object sender, EventArgs e)
        {
            
        }

        private void lb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void ptb_crear_Click(object sender, EventArgs e)
        {
            
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_Telefono_empleado.id_telefono_empleadoM = long.Parse(txt_codigo.Text);
            obj_Telefono_empleado.numero_telefono_empleadoM = int.Parse(txt_numero.Text);
            obj_Telefono_empleado.id_empleado_fk_telefono_empleadoM = long.Parse(txt_codigo_empleado.Text);
            obj_Telefono_empleado.insertar_telefono_empleado();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_Telefono_empleado.Consultageneral_tel_empleado(ref dgv_telefono_empleado);
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_telefonos telefonos = new frm_Menu_telefonos();
            telefonos.Show();
            this.Hide();
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono del empleado que desea actualizar");
            }
            else if (txt_codigo.Text != "")
            {
                obj_Telefono_empleado.id_telefono_empleadoM = long.Parse(txt_codigo.Text);
                obj_Telefono_empleado.numero_telefono_empleadoM = int.Parse(txt_numero.Text);
                obj_Telefono_empleado.id_empleado_fk_telefono_empleadoM = long.Parse(txt_codigo_empleado.Text);
                obj_Telefono_empleado.actualizar_telefono_empleado();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_codigo.Text = "";
            txt_numero.Text = "";
            txt_codigo_empleado.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_codigo.Text == "")
            {
                MessageBox.Show("Digite el codigo del telefono empleado que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_Telefono_empleado.id_telefono_empleadoM = long.Parse(txt_codigo.Text);
                obj_Telefono_empleado.eliminar_telefono_empleado();
            }
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_numero_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_codigo_empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
