﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class Frm_login : Form
    {
        public Frm_login()
        {
            InitializeComponent();
        }

        BASE_DE_DATOS.Conexion   con = new BASE_DE_DATOS.Conexion();
        LOGICA.Clase_usuario obj_usuario = new LOGICA.Clase_usuario();
        LOGICA.VALIDACION_DATOS obj_validacion = new LOGICA.VALIDACION_DATOS();
        private void lb_atras_Click(object sender, EventArgs e)
        {
            Frm_Inicio ini = new Frm_Inicio();
            ini.Show();
            this.Hide();
        }

        private void lb_iniciar_Click(object sender, EventArgs e)
        {
            if (txt_usuario.Text == "" & txt_contraseña.Text == "")
            {
                MessageBox.Show("Digite el nombre del usuario y la contraseña validos para ingresar", "Campo vacío", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                obj_usuario.Datos_usuario(txt_usuario.Text, txt_contraseña.Text);
                obj_usuario.validacion_usuario(ref txt_val_usuario, ref txt_val_contraseña);
            }

            if ((txt_val_usuario.Text != "") && (txt_val_contraseña.Text != ""))

            {
                frm_Menu_priincipal priincipal = new frm_Menu_priincipal();
                priincipal.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("Intente nuevamente. usuario o contraseña errada", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
                
        }

        private void Frm_login_Load(object sender, EventArgs e)
        {
            txt_val_usuario.Visible = false;
            txt_val_contraseña.Visible = false;
        }

        private void txt_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_letras(e);
        }
    }
}
