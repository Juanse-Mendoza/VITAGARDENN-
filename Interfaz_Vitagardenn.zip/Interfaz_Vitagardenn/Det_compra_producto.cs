﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LOGICA;

namespace Vitagardenn_interfaz
{
    public partial class frm_Det_compra_producto : Form
    {
        LOGICA.VALIDACION_DATOS obj_validacion = new VALIDACION_DATOS();
        LOGICA.Clase_detalle_compra_producto obj_compra = new Clase_detalle_compra_producto();
        public frm_Det_compra_producto()
        {
            InitializeComponent();
        }

        private void Btn_volver_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles detalles = new frm_Menu_detalles();
            detalles.Show();
            this.Hide();
        }

        private void Btn_crear_Click(object sender, EventArgs e)
        {
            obj_compra.fechaM = txt_fecha.Text;
            obj_compra.horaM = int.Parse(txt_hora.Text);
            obj_compra.id_producto_fk_compra_productoM = long.Parse(txt_cod_producto.Text);
            obj_compra.id_compra_fk_compra_productoM = long.Parse(txt_codigo_compra.Text);
            obj_compra.insertar_compra_producto();
        }

        private void Btn_consultar_Click(object sender, EventArgs e)
        {
            obj_compra.Consultageneral_compra_producto(ref dgv_compra_producto);
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {
            if (txt_fecha.Text == "")
            {
                MessageBox.Show("Digite el codigo de la compra del producto que desea actualizar");
            }
            else if (txt_fecha.Text != "")
            {
                obj_compra.fechaM = txt_fecha.Text;
                obj_compra.horaM = int.Parse(txt_hora.Text);
                obj_compra.id_producto_fk_compra_productoM = long.Parse(txt_cod_producto.Text);
                obj_compra.id_compra_fk_compra_productoM = long.Parse(txt_codigo_compra.Text);
                obj_compra.actualizar_compra_producto();

                Limpiar();
            }
        }

        private void Limpiar()
        {
            txt_fecha.Text = "";
            txt_hora.Text = "";
            txt_cod_producto.Text = "";
            txt_codigo_compra.Text = "";
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (txt_fecha.Text == "")
            {
                MessageBox.Show("Digite el codigo de la compra del producto que desea eliminar");
            }
            else if (MessageBox.Show("¿Desea eliminar este registro?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                obj_compra.fechaM = txt_fecha.Text;
                obj_compra.eliminar_compra_producto();
            }
        }

        private void txt_codigo_compra_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }

        private void txt_cod_producto_KeyPress(object sender, KeyPressEventArgs e)
        {
            obj_validacion.validacion_numeros(e);
        }
    }
}
