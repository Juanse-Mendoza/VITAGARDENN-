﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vitagardenn_interfaz
{
    public partial class frm_Menu_priincipal : Form
    {
        public frm_Menu_priincipal()
        {
            InitializeComponent();
        }

        private void Btn_menu_principal_Click(object sender, EventArgs e)
        {
            Frm_Menu_mod_principal MenuMod = new Frm_Menu_mod_principal();
            MenuMod.Show();
            this.Hide();
        }

        private void Btn_menu_productos_Click(object sender, EventArgs e)
        {
            Frm_Menu_productos menuprod = new Frm_Menu_productos();
            menuprod.Show();
            this.Hide();
        }

        private void Btn_telefonos_Click(object sender, EventArgs e)
        {
            frm_Menu_telefonos mentel = new frm_Menu_telefonos();
            mentel.Show();
            this.Hide();
        }

        private void Btn_detalles_Click(object sender, EventArgs e)
        {
            frm_Menu_detalles menudet = new frm_Menu_detalles();
            menudet.Show();
            this.Hide();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            Frm_login log = new Frm_login();
            log.Show();
            this.Hide();
        }

        private void Btn_reportes_Click(object sender, EventArgs e)
        {
            frm_Menu_Factura reportes = new frm_Menu_Factura();
            reportes.Show();
            this.Hide();
        }
    }
}
